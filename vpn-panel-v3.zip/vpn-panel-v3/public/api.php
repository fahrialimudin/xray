<?php
// ============================================================
// VPN Panel API v3 - Compatible dengan autoscript xray-optimized
// Metode inject: sed (sama persis dengan autoscript asli)
// ============================================================
header('Content-Type: application/json');
header('X-Content-Type-Options: nosniff');

define('XRAY_CONFIG', '/etc/xray/config.json');
define('DOMAIN_FILE', '/etc/xray/domain');
define('MY_IP_FILE',  '/etc/myipvps');
define('SSH_LOG',     '/etc/log-create-ssh.log');
define('VMESS_LOG',   '/etc/log-create-vmess.log');
define('VLESS_LOG',   '/etc/log-create-vless.log');
define('TROJAN_LOG',  '/etc/log-create-trojan.log');
define('SS_LOG',      '/etc/log-create-shadowsocks.log');

function ok($data = [], $msg = 'OK') {
    echo json_encode(['success'=>true,'message'=>$msg,'data'=>$data]); exit;
}
function fail($msg = 'Error') {
    echo json_encode(['success'=>false,'message'=>$msg,'data'=>null]); exit;
}
function run($cmd) {
    return trim(shell_exec('sudo ' . $cmd . ' 2>&1') ?? '');
}
function getDomain() {
    if (file_exists(DOMAIN_FILE)) { $d = trim(file_get_contents(DOMAIN_FILE)); if ($d) return $d; }
    if (file_exists(MY_IP_FILE))  { $d = trim(file_get_contents(MY_IP_FILE));  if ($d) return $d; }
    return run('curl -s ifconfig.me');
}
function getIP() {
    if (file_exists(MY_IP_FILE)) return trim(file_get_contents(MY_IP_FILE));
    return run('curl -s ifconfig.me');
}
function validUser($u) { return preg_match('/^[a-zA-Z0-9_]{3,20}$/', $u); }
function genPass($n=10) {
    $c='abcdefghjkmnpqrstuvwxyzABCDEFGHJKMNPQRSTUVWXYZ23456789';
    $p=''; for($i=0;$i<$n;$i++) $p.=$c[random_int(0,strlen($c)-1)]; return $p;
}
function getUUID() { return trim(shell_exec('cat /proc/sys/kernel/random/uuid 2>/dev/null') ?? ''); }

// ============================================================
// KUNCI UTAMA: Inject user ke xray config pakai sed
// Persis sama dengan cara autoscript asli bekerja
// Format marker: #vmess #vless #trojanws #ssws #vmessgrpc dst
// ============================================================
function sedInject($marker, $newline) {
    // Escape untuk sed
    $m  = escapeshellarg($marker);
    $nl = str_replace(["'","\\"], ["\\'","\\\\"], $newline);
    $cmd = "sed -i '/{$marker}$/a\\" . $newline . "' " . XRAY_CONFIG;
    return shell_exec('sudo ' . $cmd . ' 2>&1');
}

function injectVmess($user, $uuid, $exp) {
    // Format sama persis dengan add-ws.sh:
    // sed -i '/#vmess$/a\### user exp\n},{"id": "uuid","alterId": 0,"email": "user"'
    $line1 = '### ' . $user . ' ' . $exp;
    $line2 = '},{"id": "' . $uuid . '","alterId": 0,"email": "' . $user . '"';
    $cfg = XRAY_CONFIG;
    shell_exec("sudo sed -i '/#vmess\$/a\\\n" . $line1 . "\\\n" . $line2 . "' {$cfg} 2>&1");
    shell_exec("sudo sed -i '/#vmessgrpc\$/a\\\n" . $line1 . "\\\n" . $line2 . "' {$cfg} 2>&1");
}

function injectVless($user, $uuid, $exp) {
    // Format sama persis dengan add-vless.sh:
    // sed -i '/#vless$/a\#& user exp\n},{"id": "uuid","email": "user"'
    $line1 = '#& ' . $user . ' ' . $exp;
    $line2 = '},{"id": "' . $uuid . '","email": "' . $user . '"';
    $cfg = XRAY_CONFIG;
    shell_exec("sudo sed -i '/#vless\$/a\\\n" . $line1 . "\\\n" . $line2 . "' {$cfg} 2>&1");
    shell_exec("sudo sed -i '/#vlessgrpc\$/a\\\n" . $line1 . "\\\n" . $line2 . "' {$cfg} 2>&1");
}

function injectTrojan($user, $pass, $exp) {
    // Format sama persis dengan add-tr.sh:
    // sed -i '/#trojanws$/a\#! user exp\n},{"password": "pass","email": "user"'
    $line1 = '#! ' . $user . ' ' . $exp;
    $line2 = '},{"password": "' . $pass . '","email": "' . $user . '"';
    $cfg = XRAY_CONFIG;
    shell_exec("sudo sed -i '/#trojanws\$/a\\\n" . $line1 . "\\\n" . $line2 . "' {$cfg} 2>&1");
    shell_exec("sudo sed -i '/#trojangrpc\$/a\\\n" . $line1 . "\\\n" . $line2 . "' {$cfg} 2>&1");
}

function injectSS($user, $pass, $exp) {
    $line1 = '#ss ' . $user . ' ' . $exp;
    $line2 = '},{"method": "aes-128-gcm","password": "' . $pass . '","email": "' . $user . '"';
    $cfg = XRAY_CONFIG;
    shell_exec("sudo sed -i '/#ssws\$/a\\\n" . $line1 . "\\\n" . $line2 . "' {$cfg} 2>&1");
    shell_exec("sudo sed -i '/#ssgrpc\$/a\\\n" . $line1 . "\\\n" . $line2 . "' {$cfg} 2>&1");
}

// Cek apakah user sudah ada di config
function userExistsInConfig($user) {
    $count = (int) shell_exec('sudo grep -w "' . $user . '" ' . XRAY_CONFIG . ' 2>/dev/null | wc -l');
    return $count > 0;
}

function getSshStatus($user) {
    $s = trim(shell_exec("sudo grep \"^{$user}:\" /etc/shadow 2>/dev/null | cut -d: -f2") ?? '');
    if (!$s || str_starts_with($s,'!') || str_starts_with($s,'*')) return 'locked';
    return 'active';
}

// ============================================================
$input  = json_decode(file_get_contents('php://input'), true) ?? [];
$action = $input['action'] ?? '';

switch ($action) {

// ── STATS ────────────────────────────────────────────────────
case 'stats':
    $ssh_count  = (int) run("awk -F: '\$3>=1000 && \$1!=\"nobody\"{print \$1}' /etc/passwd | wc -l");
    $xray_count = (int) shell_exec('sudo grep -c "email" ' . XRAY_CONFIG . ' 2>/dev/null') ?: 0;
    $mt = (int) run("grep MemTotal /proc/meminfo | awk '{print \$2}'");
    $ma = (int) run("grep MemAvailable /proc/meminfo | awk '{print \$2}'");
    $ram = $mt>0 ? round(($mt-$ma)/1024).'/'.round($mt/1024).'MB' : '0/0MB';
    $up = (int) run("awk '{print int(\$1)}' /proc/uptime");
    $uptime = ($up>=86400?intdiv($up,86400).'d ':'').intdiv($up%86400,3600).'h';
    ok(['ssh_users'=>$ssh_count,'xray_users'=>$xray_count,'ram'=>$ram,'uptime'=>$uptime,'ip'=>getIP()]);

// ── CREATE SSH ───────────────────────────────────────────────
case 'create_ssh':
    $user = trim($input['user'] ?? '');
    $pass = trim($input['pass'] ?? '');
    $exp  = (int)($input['exp'] ?? 30);
    $host = getDomain();
    if (!validUser($user)) fail('Username tidak valid (3-20 karakter, huruf/angka/_)');
    if (strlen($pass) < 4)  fail('Password minimal 4 karakter');
    if ($exp<1||$exp>365)   fail('Expired harus 1-365 hari');
    if (strpos(run("id {$user}"),'uid=')!==false) fail("User '{$user}' sudah ada");
    $exp_date = date('Y-m-d', strtotime("+{$exp} days"));
    run("useradd -e {$exp_date} -s /bin/false -M {$user}");
    run("echo '{$user}:{$pass}' | chpasswd");
    if (strpos(run("id {$user}"),'uid=')===false) fail('Gagal buat user, cek sudoers');
    $log = date('Y-m-d H:i:s')." | user:{$user} | pass:{$pass} | exp:{$exp_date}\n";
    @file_put_contents(SSH_LOG, $log, FILE_APPEND);
    ok(['user'=>$user,'pass'=>$pass,'exp_date'=>$exp_date,'host'=>$host,
        'openssh'=>'22, 9696','dropbear'=>'109, 143','stunnel'=>'222, 777',
        'ws_http'=>'80','ws_https'=>'443','udpgw'=>'7100-7400'], 'SSH account created');

// ── CREATE VMESS ─────────────────────────────────────────────
case 'create_vmess':
    $user = trim($input['user'] ?? '');
    $exp  = (int)($input['exp'] ?? 30);
    $host = getDomain();
    if (!validUser($user))  fail('Username tidak valid');
    if ($exp<1||$exp>365)   fail('Expired harus 1-365 hari');
    if (!file_exists(XRAY_CONFIG)) fail('Xray config tidak ditemukan');
    if (userExistsInConfig($user)) fail("User '{$user}' sudah ada di xray config");
    $uuid     = getUUID(); if (!$uuid) fail('Gagal generate UUID');
    $exp_date = date('Y-m-d', strtotime("+{$exp} days"));
    // Cek marker ada
    $has_marker = (int) shell_exec('sudo grep -c "#vmess$" ' . XRAY_CONFIG . ' 2>/dev/null');
    if ($has_marker < 1) fail('Marker #vmess tidak ditemukan di config. Pastikan autoscript terinstall dengan benar.');
    injectVmess($user, $uuid, $exp_date);
    run('systemctl restart xray'); sleep(1);
    if (run('systemctl is-active xray') !== 'active') fail('User ditambahkan tapi xray gagal restart');
    // Generate link (format sama dengan autoscript)
    $tls_obj  = ['v'=>'2','ps'=>$user,'add'=>$host,'port'=>'443','id'=>$uuid,'aid'=>'0','net'=>'ws','path'=>'/vmess','type'=>'none','host'=>'','tls'=>'tls'];
    $http_obj = ['v'=>'2','ps'=>$user,'add'=>$host,'port'=>'80', 'id'=>$uuid,'aid'=>'0','net'=>'ws','path'=>'/vmess','type'=>'none','host'=>'','tls'=>'none'];
    $grpc_obj = ['v'=>'2','ps'=>$user,'add'=>$host,'port'=>'443','id'=>$uuid,'aid'=>'0','net'=>'grpc','path'=>'vmess-grpc','type'=>'none','host'=>'','tls'=>'tls'];
    $link_tls  = 'vmess://'.base64_encode(json_encode($tls_obj));
    $link_http = 'vmess://'.base64_encode(json_encode($http_obj));
    $link_grpc = 'vmess://'.base64_encode(json_encode($grpc_obj));
    @file_put_contents(VMESS_LOG, date('Y-m-d H:i:s')." | user:{$user} | uuid:{$uuid} | exp:{$exp_date}\n", FILE_APPEND);
    ok(['user'=>$user,'uuid'=>$uuid,'host'=>$host,'exp_date'=>$exp_date,
        'port_tls'=>443,'port_http'=>80,'path'=>'/vmess','grpc_service'=>'vmess-grpc',
        'link_tls'=>$link_tls,'link_http'=>$link_http,'link_grpc'=>$link_grpc], 'Vmess account created');

// ── CREATE VLESS ─────────────────────────────────────────────
case 'create_vless':
    $user = trim($input['user'] ?? '');
    $exp  = (int)($input['exp'] ?? 30);
    $host = getDomain();
    if (!validUser($user))  fail('Username tidak valid');
    if ($exp<1||$exp>365)   fail('Expired harus 1-365 hari');
    if (!file_exists(XRAY_CONFIG)) fail('Xray config tidak ditemukan');
    if (userExistsInConfig($user)) fail("User '{$user}' sudah ada di xray config");
    $uuid     = getUUID(); if (!$uuid) fail('Gagal generate UUID');
    $exp_date = date('Y-m-d', strtotime("+{$exp} days"));
    $has_marker = (int) shell_exec('sudo grep -c "#vless$" ' . XRAY_CONFIG . ' 2>/dev/null');
    if ($has_marker < 1) fail('Marker #vless tidak ditemukan di config');
    injectVless($user, $uuid, $exp_date);
    run('systemctl restart xray'); sleep(1);
    if (run('systemctl is-active xray') !== 'active') fail('User ditambahkan tapi xray gagal restart');
    $link_tls  = "vless://{$uuid}@{$host}:443?path=%2Fvless&security=tls&encryption=none&type=ws#{$user}";
    $link_http = "vless://{$uuid}@{$host}:80?path=%2Fvless&encryption=none&type=ws#{$user}";
    $link_grpc = "vless://{$uuid}@{$host}:443?mode=gun&security=tls&encryption=none&type=grpc&serviceName=vless-grpc#{$user}";
    @file_put_contents(VLESS_LOG, date('Y-m-d H:i:s')." | user:{$user} | uuid:{$uuid} | exp:{$exp_date}\n", FILE_APPEND);
    ok(['user'=>$user,'uuid'=>$uuid,'host'=>$host,'exp_date'=>$exp_date,
        'port_tls'=>443,'port_http'=>80,'path'=>'/vless','grpc_service'=>'vless-grpc',
        'link_tls'=>$link_tls,'link_http'=>$link_http,'link_grpc'=>$link_grpc], 'Vless account created');

// ── CREATE TROJAN ─────────────────────────────────────────────
case 'create_trojan':
    $user = trim($input['user'] ?? '');
    $exp  = (int)($input['exp'] ?? 30);
    $host = getDomain();
    if (!validUser($user))  fail('Username tidak valid');
    if ($exp<1||$exp>365)   fail('Expired harus 1-365 hari');
    if (!file_exists(XRAY_CONFIG)) fail('Xray config tidak ditemukan');
    if (userExistsInConfig($user)) fail("User '{$user}' sudah ada di xray config");
    $pass     = getUUID(); if (!$pass) fail('Gagal generate password');
    $exp_date = date('Y-m-d', strtotime("+{$exp} days"));
    $has_marker = (int) shell_exec('sudo grep -c "#trojanws$" ' . XRAY_CONFIG . ' 2>/dev/null');
    if ($has_marker < 1) fail('Marker #trojanws tidak ditemukan di config');
    injectTrojan($user, $pass, $exp_date);
    run('systemctl restart xray'); sleep(1);
    if (run('systemctl is-active xray') !== 'active') fail('User ditambahkan tapi xray gagal restart');
    $link_tls  = "trojan://{$pass}@{$host}:443?path=%2Ftrojan-ws&security=tls&host={$host}&type=ws&sni={$host}#{$user}";
    $link_http = "trojan://{$pass}@{$host}:80?path=%2Ftrojan-ws&security=none&host={$host}&type=ws#{$user}";
    $link_grpc = "trojan://{$pass}@{$host}:443?mode=gun&security=tls&type=grpc&serviceName=trojan-grpc&sni={$host}#{$user}";
    @file_put_contents(TROJAN_LOG, date('Y-m-d H:i:s')." | user:{$user} | pass:{$pass} | exp:{$exp_date}\n", FILE_APPEND);
    ok(['user'=>$user,'pass'=>$pass,'host'=>$host,'exp_date'=>$exp_date,
        'port_tls'=>443,'port_http'=>80,'path'=>'/trojan-ws','grpc_service'=>'trojan-grpc',
        'link_tls'=>$link_tls,'link_http'=>$link_http,'link_grpc'=>$link_grpc], 'Trojan account created');

// ── CREATE SHADOWSOCKS ────────────────────────────────────────
case 'create_ss':
    $user = trim($input['user'] ?? '');
    $exp  = (int)($input['exp'] ?? 30);
    $host = getDomain();
    if (!validUser($user))  fail('Username tidak valid');
    if ($exp<1||$exp>365)   fail('Expired harus 1-365 hari');
    if (!file_exists(XRAY_CONFIG)) fail('Xray config tidak ditemukan');
    if (userExistsInConfig($user)) fail("User '{$user}' sudah ada di xray config");
    $pass     = genPass(16);
    $exp_date = date('Y-m-d', strtotime("+{$exp} days"));
    $has_marker = (int) shell_exec('sudo grep -c "#ssws$" ' . XRAY_CONFIG . ' 2>/dev/null');
    if ($has_marker < 1) fail('Marker #ssws tidak ditemukan di config');
    injectSS($user, $pass, $exp_date);
    run('systemctl restart xray'); sleep(1);
    if (run('systemctl is-active xray') !== 'active') fail('User ditambahkan tapi xray gagal restart');
    $ss_b64   = base64_encode("aes-128-gcm:{$pass}");
    $link_tls  = "ss://{$ss_b64}@{$host}:443?plugin=v2ray-plugin%3Btls%3Bmode%3Dwebsocket%3Bpath%3D%2Fss-ws%3Bhost%3D{$host}#{$user}";
    $link_http = "ss://{$ss_b64}@{$host}:80?plugin=v2ray-plugin%3Bmode%3Dwebsocket%3Bpath%3D%2Fss-ws%3Bhost%3D{$host}#{$user}";
    @file_put_contents(SS_LOG, date('Y-m-d H:i:s')." | user:{$user} | pass:{$pass} | exp:{$exp_date}\n", FILE_APPEND);
    ok(['user'=>$user,'pass'=>$pass,'method'=>'aes-128-gcm','host'=>$host,'exp_date'=>$exp_date,
        'link_tls'=>$link_tls,'link_http'=>$link_http], 'Shadowsocks account created');

// ── LIST USERS ────────────────────────────────────────────────
case 'list_users':
    $ssh = [];
    foreach (explode("\n", run("awk -F: '\$3>=1000&&\$1!=\"nobody\"{print \$1}' /etc/passwd")) as $u) {
        $u = trim($u); if (!$u) continue;
        $exp = run("chage -l {$u} 2>/dev/null | grep 'Account expires' | cut -d: -f2");
        $ssh[] = ['user'=>$u,'exp'=>trim($exp)?:'never','status'=>getSshStatus($u)];
    }
    // Parse xray users dari config - baca email field
    $xray = [];
    if (file_exists(XRAY_CONFIG)) {
        $raw = file_get_contents(XRAY_CONFIG);
        // Ambil semua baris email dengan protokol dari context
        preg_match_all('/"email":\s*"([^"@]+)@([^"]+)"/', $raw, $m);
        $seen = [];
        for ($i=0; $i<count($m[1]); $i++) {
            $uname = $m[1][$i];
            $proto = strtoupper($m[2][$i]);
            // Sederhanakan: vmess, vless, trojan, ss
            $proto = preg_replace('/grpc/i','gRPC',$proto);
            $key = $uname.'_'.$proto;
            if (!isset($seen[$key])) {
                $seen[$key] = 1;
                // Cari tanggal expired dari komentar ### atau #& atau #!
                $expDate = '';
                if (preg_match('/(?:###|#&|#!|#ss)\s+'.preg_quote($uname,'/').'\s+([\d-]+)/', $raw, $dm)) {
                    $expDate = $dm[1];
                }
                $xray[] = ['user'=>$uname,'type'=>$proto,'exp'=>$expDate?:'-'];
            }
        }
    }
    ok(['ssh'=>$ssh,'xray'=>$xray]);

// ── DELETE SSH ────────────────────────────────────────────────
case 'delete_ssh':
    $user = trim($input['user'] ?? '');
    if (!validUser($user)) fail('Username tidak valid');
    if (strpos(run("id {$user}"),'uid=')===false) fail("User tidak ditemukan");
    run("pkill -u {$user}"); run("userdel -f {$user}");
    ok([], "User SSH '{$user}' dihapus");

// ── DELETE XRAY ───────────────────────────────────────────────
case 'delete_xray':
    $user = trim($input['user'] ?? '');
    if (!validUser($user)) fail('Username tidak valid');
    if (!file_exists(XRAY_CONFIG)) fail('Config tidak ditemukan');
    // Hapus semua baris yang mengandung nama user dari config
    run("sed -i '/\b{$user}\b/d' " . XRAY_CONFIG);
    run('systemctl restart xray'); sleep(1);
    ok([], "User xray '{$user}' dihapus");

// ── SERVICE STATUS ────────────────────────────────────────────
case 'service_status':
    $svcs  = ['xray','nginx','ssh','dropbear','stunnel4','ws-dropbear','ws-stunnel','fail2ban','cron'];
    $names = ['Xray','Nginx','OpenSSH','Dropbear','Stunnel4','WS-Dropbear','WS-Stunnel','Fail2Ban','Cron'];
    $res = [];
    foreach ($svcs as $i=>$s) $res[] = ['name'=>$names[$i],'svc'=>$s,'status'=>run("systemctl is-active {$s}")];
    ok($res);

// ── RESTART SERVICE ───────────────────────────────────────────
case 'restart_service':
    $name = $input['name'] ?? '';
    $allowed = ['xray','nginx','ssh','dropbear','stunnel4','ws-dropbear','ws-stunnel','fail2ban','cron'];
    if (!in_array($name,$allowed)) fail('Service tidak diizinkan');
    run("systemctl restart {$name}");
    $st = run("systemctl is-active {$name}");
    if ($st==='active') ok([],"$name berhasil direstart");
    else fail("$name gagal restart: $st");

// ── DEBUG ─────────────────────────────────────────────────────
case 'debug':
    $markers = ['#vmess','#vless','#trojanws','#ssws','#vmessgrpc','#vlessgrpc','#trojangrpc','#ssgrpc'];
    $found = [];
    foreach ($markers as $m) {
        $c = (int) shell_exec('sudo grep -c "'.substr($m,1).'$" '.XRAY_CONFIG.' 2>/dev/null');
        $found[$m] = $c > 0;
    }
    ok(['xray_status'=>run('systemctl is-active xray'),
        'config_exists'=>file_exists(XRAY_CONFIG),
        'config_size'=>file_exists(XRAY_CONFIG)?filesize(XRAY_CONFIG).'B':'0',
        'markers'=>$found,
        'domain'=>getDomain()]);

default:
    fail('Action tidak dikenal: '.$action);
}
