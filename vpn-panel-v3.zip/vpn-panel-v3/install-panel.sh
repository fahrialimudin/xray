#!/bin/bash
# ============================================================
# Install VPN Panel v3 - Compatible autoscript xray-optimized
# ============================================================
GREEN='\e[1;32m'; CYAN='\e[1;36m'; RED='\e[1;31m'; YELLOW='\e[1;33m'; NC='\e[0m'

echo -e "${CYAN}============================================${NC}"
echo -e "${CYAN}     Install VPN Panel v3                  ${NC}"
echo -e "${CYAN}     Compatible: xray-optimized            ${NC}"
echo -e "${CYAN}============================================${NC}"

# Cek root
[ "$EUID" -ne 0 ] && echo -e "${RED}Jalankan sebagai root!${NC}" && exit 1

# [1] Install PHP
echo -e "${GREEN}[1/6] Install PHP...${NC}"
apt update -y >/dev/null 2>&1
apt install -y php8.3 php8.3-fpm php8.3-cli php8.3-common >/dev/null 2>&1 || \
apt install -y php php-fpm php-cli php-common >/dev/null 2>&1

PHP_VER=$(php -r 'echo PHP_MAJOR_VERSION.".".PHP_MINOR_VERSION;' 2>/dev/null)
echo -e "${GREEN}   PHP: $PHP_VER${NC}"

# [2] Start PHP-FPM
echo -e "${GREEN}[2/6] Start PHP-FPM...${NC}"
systemctl enable php${PHP_VER}-fpm >/dev/null 2>&1
systemctl start  php${PHP_VER}-fpm >/dev/null 2>&1
SOCK=$(ls /run/php/php${PHP_VER}-fpm.sock 2>/dev/null || ls /run/php/*.sock 2>/dev/null | head -1)
echo -e "${GREEN}   Socket: $SOCK${NC}"

# [3] Deploy file panel
echo -e "${GREEN}[3/6] Deploy file panel...${NC}"
mkdir -p /home/vps/public_html
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cp "$SCRIPT_DIR/public/index.php" /home/vps/public_html/index.php
cp "$SCRIPT_DIR/public/api.php"   /home/vps/public_html/api.php
chown -R www-data:www-data /home/vps/public_html
chmod 755 /home/vps/public_html
chmod 644 /home/vps/public_html/*.php
echo -e "${GREEN}   ✅ File panel di-deploy${NC}"

# [4] Sudoers
echo -e "${GREEN}[4/6] Setup sudoers...${NC}"
cat > /etc/sudoers.d/vpnpanel <<-EOF
www-data ALL=(ALL) NOPASSWD: ALL
EOF
chmod 440 /etc/sudoers.d/vpnpanel

# [5] Konfigurasi Nginx
echo -e "${GREEN}[5/6] Konfigurasi Nginx...${NC}"
DOMAIN=""
[ -f /etc/xray/domain ] && DOMAIN=$(cat /etc/xray/domain)
[ -z "$DOMAIN" ] && [ -f /etc/myipvps ] && DOMAIN=$(cat /etc/myipvps)
[ -z "$DOMAIN" ] && DOMAIN=$(curl -s ifconfig.me 2>/dev/null)
echo -e "${GREEN}   Domain: $DOMAIN${NC}"

# Cek SSL cert
SSL_CRT="/etc/xray/xray.crt"
SSL_KEY="/etc/xray/xray.key"
if [ -f "$SSL_CRT" ] && [ -f "$SSL_KEY" ]; then
    echo -e "${GREEN}   ✅ SSL cert ditemukan${NC}"
else
    echo -e "${YELLOW}   ⚠️  SSL cert tidak ditemukan, port 443 tanpa TLS${NC}"
fi

# Nginx config panel (port 8080) - TERPISAH dari xray config
cat > /etc/nginx/conf.d/vpn-panel.conf <<-NGINXEOF
server {
    listen 8080;
    server_name _;
    root /home/vps/public_html;
    index index.php index.html;

    location / {
        try_files \$uri \$uri/ /index.php?\$query_string;
    }

    location ~ \.php\$ {
        include snippets/fastcgi-php.conf;
        fastcgi_pass unix:${SOCK};
        fastcgi_param SCRIPT_FILENAME \$document_root\$fastcgi_script_name;
        include fastcgi_params;
    }

    location ~ /\.ht { deny all; }
}
NGINXEOF

# Fix nginx xray config - hapus http2 agar WebSocket bisa upgrade
# http2 tidak support WebSocket Upgrade header
XRAY_NGINX=""
for f in /etc/nginx/conf.d/xray.conf /etc/nginx/conf.d/v2ray.conf; do
    [ -f "$f" ] && XRAY_NGINX="$f" && break
done

if [ -n "$XRAY_NGINX" ]; then
    echo -e "${GREEN}   Fix nginx xray (remove http2)...${NC}"
    cp "$XRAY_NGINX" "${XRAY_NGINX}.bak"
    # Hapus http2 dari listen directive (penyebab WS 400 Bad Request)
    sed -i 's/listen \(.*\) ssl http2/listen \1 ssl/g' "$XRAY_NGINX"
    sed -i 's/listen \(.*\) http2/listen \1/g' "$XRAY_NGINX"
    echo -e "${GREEN}   ✅ http2 dihapus dari nginx config${NC}"
fi

# [6] Test & Reload Nginx
echo -e "${GREEN}[6/6] Test & Reload Nginx...${NC}"
if nginx -t >/dev/null 2>&1; then
    systemctl reload nginx
    echo -e "${GREEN}   ✅ Nginx reload berhasil${NC}"
else
    echo -e "${RED}   ❌ Nginx config error:${NC}"
    nginx -t
fi

# Test API
sleep 1
RESULT=$(curl -s -X POST http://localhost:8080/api.php \
  -H "Content-Type: application/json" \
  -d '{"action":"stats"}')
if echo "$RESULT" | grep -q '"success":true'; then
    echo -e "${GREEN}   ✅ API berjalan!${NC}"
else
    echo -e "${YELLOW}   ⚠️  API: $RESULT${NC}"
fi

# Debug xray markers
echo -e "${GREEN}   Cek xray markers...${NC}"
DEBUG=$(curl -s -X POST http://localhost:8080/api.php \
  -H "Content-Type: application/json" \
  -d '{"action":"debug"}')
echo "$DEBUG" | python3 -c "
import sys, json
d = json.load(sys.stdin)
if d.get('success'):
    data = d['data']
    print('  Xray status :', data.get('xray_status'))
    print('  Domain      :', data.get('domain'))
    print('  Markers:')
    for k,v in data.get('markers',{}).items():
        status = '✅' if v else '❌'
        print(f'    {status} {k}')
" 2>/dev/null || echo "$DEBUG"

echo -e ""
echo -e "${CYAN}============================================${NC}"
echo -e "${CYAN}   Panel berhasil diinstall!               ${NC}"
echo -e "${CYAN}============================================${NC}"
echo -e ""
echo -e " Akses panel: ${GREEN}http://${DOMAIN}:8080${NC}"
echo -e ""
