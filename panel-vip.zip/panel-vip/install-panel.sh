#!/bin/bash
# ============================================================
# Install VPN Panel v3 - Fixed
# Port: 1313
# Compatible: autoscript xray-optimized (Ubuntu 22/24)
# ============================================================
GREEN='\e[1;32m'; CYAN='\e[1;36m'; RED='\e[1;31m'; YELLOW='\e[1;33m'; NC='\e[0m'

echo -e "${CYAN}============================================${NC}"
echo -e "${CYAN}     Install VPN Panel v3 (Fixed)          ${NC}"
echo -e "${CYAN}     Port: 1313                            ${NC}"
echo -e "${CYAN}     Compatible: xray-optimized            ${NC}"
echo -e "${CYAN}============================================${NC}"

# Cek root
[ "$EUID" -ne 0 ] && echo -e "${RED}Jalankan sebagai root!${NC}" && exit 1

# [1] Install PHP
echo -e "${GREEN}[1/6] Install PHP...${NC}"
apt update -y >/dev/null 2>&1
apt install -y php8.3 php8.3-fpm php8.3-cli php8.3-common >/dev/null 2>&1 || \
apt install -y php php-fpm php-cli php-common >/dev/null 2>&1

PHP_VER=$(php -r 'echo PHP_MAJOR_VERSION.".".PHP_MINOR_VERSION;' 2>/dev/null)
echo -e "${GREEN}   PHP: $PHP_VER${NC}"

# [2] Start PHP-FPM
echo -e "${GREEN}[2/6] Start PHP-FPM...${NC}"
systemctl enable php${PHP_VER}-fpm >/dev/null 2>&1
systemctl start  php${PHP_VER}-fpm >/dev/null 2>&1
SOCK=$(ls /run/php/php${PHP_VER}-fpm.sock 2>/dev/null || ls /run/php/*.sock 2>/dev/null | head -1)
if [ -z "$SOCK" ]; then
    echo -e "${RED}   ERROR: PHP-FPM socket tidak ditemukan!${NC}"
    exit 1
fi
echo -e "${GREEN}   Socket: $SOCK${NC}"

# [3] Deploy file panel
echo -e "${GREEN}[3/6] Deploy file panel...${NC}"
mkdir -p /home/vps/public_html
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cp "$SCRIPT_DIR/public/index.php" /home/vps/public_html/index.php
cp "$SCRIPT_DIR/public/api.php"   /home/vps/public_html/api.php
chown -R www-data:www-data /home/vps/public_html
chmod 755 /home/vps/public_html
chmod 644 /home/vps/public_html/*.php
echo -e "${GREEN}   ✅ File panel di-deploy${NC}"

# [4] Sudoers - www-data bisa jalankan semua tanpa password
echo -e "${GREEN}[4/6] Setup sudoers...${NC}"
cat > /etc/sudoers.d/vpnpanel <<-EOF
www-data ALL=(ALL) NOPASSWD: ALL
EOF
chmod 440 /etc/sudoers.d/vpnpanel
echo -e "${GREEN}   ✅ Sudoers terkonfigurasi${NC}"

# Init file license (jika belum ada)
echo -e "${GREEN}   Init file license...${NC}"
# Lokasi: /var/lib/ (lebih proper, www-data bisa akses)
if [ ! -f /var/lib/vpnpanel-license.json ]; then
    echo '["fahrialimudin"]' > /var/lib/vpnpanel-license.json
fi
if [ ! -f /var/lib/vpnpanel-reseller.json ]; then
    echo '[]' > /var/lib/vpnpanel-reseller.json
fi
# Set permission agar www-data bisa baca & tulis langsung (tanpa sudo)
chmod 666 /var/lib/vpnpanel-license.json
chmod 666 /var/lib/vpnpanel-reseller.json
chown www-data:www-data /var/lib/vpnpanel-license.json 2>/dev/null || true
chown www-data:www-data /var/lib/vpnpanel-reseller.json 2>/dev/null || true

# Juga migrasi dari lokasi lama jika ada
if [ -f /etc/vpnpanel-license.json ]; then
    cp /etc/vpnpanel-license.json /var/lib/vpnpanel-license.json
    chmod 666 /var/lib/vpnpanel-license.json
    chown www-data:www-data /var/lib/vpnpanel-license.json 2>/dev/null || true
fi
if [ -f /etc/vpnpanel-reseller.json ]; then
    cp /etc/vpnpanel-reseller.json /var/lib/vpnpanel-reseller.json
    chmod 666 /var/lib/vpnpanel-reseller.json
    chown www-data:www-data /var/lib/vpnpanel-reseller.json 2>/dev/null || true
fi
echo -e "${GREEN}   ✅ File license siap (default admin: fahrialimudin)${NC}"

# [5] Konfigurasi Nginx port 1313
echo -e "${GREEN}[5/6] Konfigurasi Nginx (port 1313)...${NC}"
DOMAIN=""
[ -f /etc/xray/domain ] && DOMAIN=$(cat /etc/xray/domain)
[ -z "$DOMAIN" ] && [ -f /etc/myipvps ] && DOMAIN=$(cat /etc/myipvps)
[ -z "$DOMAIN" ] && DOMAIN=$(curl -s ifconfig.me 2>/dev/null)
echo -e "${GREEN}   Domain/IP: $DOMAIN${NC}"

# Hapus config lama jika ada (port 8080)
rm -f /etc/nginx/conf.d/vpn-panel.conf

# Buat config nginx untuk panel (port 1313) - TERPISAH dari xray
cat > /etc/nginx/conf.d/vpn-panel.conf <<-NGINXEOF
server {
    listen 1313;
    server_name _;
    root /home/vps/public_html;
    index index.php index.html;

    location / {
        try_files \$uri \$uri/ /index.php?\$query_string;
    }

    location ~ \.php\$ {
        include snippets/fastcgi-php.conf;
        fastcgi_pass unix:${SOCK};
        fastcgi_param SCRIPT_FILENAME \$document_root\$fastcgi_script_name;
        include fastcgi_params;
    }

    location ~ /\.ht { deny all; }
}
NGINXEOF

echo -e "${GREEN}   ✅ Nginx config dibuat (port 1313)${NC}"

# [6] Test & Reload Nginx
echo -e "${GREEN}[6/6] Test & Reload Nginx...${NC}"
if nginx -t >/dev/null 2>&1; then
    systemctl reload nginx
    echo -e "${GREEN}   ✅ Nginx reload berhasil${NC}"
else
    echo -e "${RED}   ❌ Nginx config error:${NC}"
    nginx -t
    exit 1
fi

# Test API
sleep 2
RESULT=$(curl -s -X POST http://localhost:1313/api.php \
  -H "Content-Type: application/json" \
  -d '{"action":"stats"}')
if echo "$RESULT" | grep -q '"success":true'; then
    echo -e "${GREEN}   ✅ API berjalan di port 1313!${NC}"
else
    echo -e "${YELLOW}   ⚠️  API response: $RESULT${NC}"
fi

# Debug xray markers
echo -e "${GREEN}   Cek xray markers...${NC}"
DEBUG=$(curl -s -X POST http://localhost:1313/api.php \
  -H "Content-Type: application/json" \
  -d '{"action":"debug"}')
echo "$DEBUG" | python3 -c "
import sys, json
try:
    d = json.load(sys.stdin)
    if d.get('success'):
        data = d['data']
        print('  Xray status :', data.get('xray_status'))
        print('  Domain      :', data.get('domain'))
        print('  PHP user    :', data.get('php_user'))
        print('  sudo test   :', data.get('sudo_test'))
        print('  Markers:')
        for k,v in data.get('markers',{}).items():
            status = '✅' if v else '❌'
            print(f'    {status} {k}')
except:
    print('Debug parse error:', sys.stdin.read())
" 2>/dev/null || echo "$DEBUG"

echo ""
echo -e "${CYAN}============================================${NC}"
echo -e "${CYAN}   Panel berhasil diinstall!               ${NC}"
echo -e "${CYAN}============================================${NC}"
echo ""
echo -e " Akses panel: ${GREEN}http://${DOMAIN}:1313${NC}"
echo ""
echo -e " Jika firewall aktif, buka port 1313:"
echo -e " ${YELLOW}ufw allow 1313/tcp${NC}"
echo ""
