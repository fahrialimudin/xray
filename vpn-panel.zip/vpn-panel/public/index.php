<?php
// ============================================================
// VPN Panel - Main Entry
// ============================================================
session_start();
header('X-Frame-Options: SAMEORIGIN');
header('X-Content-Type-Options: nosniff');
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>VPN Panel</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@300;400;600;700&family=Syne:wght@400;600;800&display=swap" rel="stylesheet">
<style>
:root {
  --bg: #0a0a0f;
  --surface: #111118;
  --surface2: #1a1a24;
  --border: #2a2a3a;
  --accent: #00e5ff;
  --accent2: #7c3aed;
  --green: #00ff88;
  --red: #ff4466;
  --yellow: #ffcc00;
  --text: #e8e8f0;
  --muted: #666680;
  --font-mono: 'JetBrains Mono', monospace;
  --font-display: 'Syne', sans-serif;
}
* { margin:0; padding:0; box-sizing:border-box; }
html { scroll-behavior: smooth; }
body {
  background: var(--bg);
  color: var(--text);
  font-family: var(--font-mono);
  min-height: 100vh;
  overflow-x: hidden;
}

/* Background grid */
body::before {
  content:'';
  position:fixed;
  inset:0;
  background-image:
    linear-gradient(rgba(0,229,255,0.03) 1px, transparent 1px),
    linear-gradient(90deg, rgba(0,229,255,0.03) 1px, transparent 1px);
  background-size: 40px 40px;
  pointer-events:none;
  z-index:0;
}

/* Header */
.header {
  position: sticky;
  top:0;
  z-index:100;
  background: rgba(10,10,15,0.92);
  backdrop-filter: blur(12px);
  border-bottom: 1px solid var(--border);
  padding: 0 24px;
  height: 56px;
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.logo {
  font-family: var(--font-display);
  font-weight: 800;
  font-size: 20px;
  color: var(--accent);
  letter-spacing: -0.5px;
}
.logo span { color: var(--text); }
.server-info {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 12px;
  color: var(--muted);
}
.dot {
  width:8px; height:8px;
  border-radius:50%;
  background: var(--green);
  box-shadow: 0 0 8px var(--green);
  animation: pulse 2s infinite;
}
@keyframes pulse {
  0%,100% { opacity:1; }
  50% { opacity:0.4; }
}

/* Layout */
.container {
  position: relative;
  z-index:1;
  max-width: 1100px;
  margin: 0 auto;
  padding: 24px 16px;
}

/* Tabs */
.tabs {
  display: flex;
  gap: 4px;
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: 10px;
  padding: 4px;
  margin-bottom: 24px;
  overflow-x: auto;
  scrollbar-width: none;
}
.tabs::-webkit-scrollbar { display:none; }
.tab {
  flex-shrink:0;
  padding: 8px 18px;
  border-radius: 7px;
  font-family: var(--font-mono);
  font-size: 13px;
  font-weight: 600;
  color: var(--muted);
  cursor: pointer;
  border: none;
  background: transparent;
  transition: all 0.2s;
  white-space: nowrap;
}
.tab:hover { color: var(--text); background: var(--surface2); }
.tab.active {
  background: var(--accent2);
  color: #fff;
  box-shadow: 0 0 16px rgba(124,58,237,0.4);
}

/* Panel content */
.panel { display: none; animation: fadeIn 0.3s ease; }
.panel.active { display: block; }
@keyframes fadeIn { from { opacity:0; transform:translateY(8px); } to { opacity:1; transform:translateY(0); } }

/* Card */
.card {
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius: 12px;
  padding: 24px;
  margin-bottom: 16px;
}
.card-title {
  font-family: var(--font-display);
  font-size: 16px;
  font-weight: 600;
  color: var(--accent);
  margin-bottom: 20px;
  display: flex;
  align-items: center;
  gap: 8px;
}
.card-title::before {
  content:'';
  width:3px; height:18px;
  background: var(--accent);
  border-radius:2px;
}

/* Form */
.form-row {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 12px;
  margin-bottom: 12px;
}
.form-row.single { grid-template-columns: 1fr; }
.form-row.triple { grid-template-columns: 1fr 1fr 1fr; }
@media(max-width:600px) {
  .form-row, .form-row.triple { grid-template-columns: 1fr; }
}
.field { display:flex; flex-direction:column; gap:6px; }
.field label {
  font-size: 11px;
  font-weight: 600;
  color: var(--muted);
  text-transform: uppercase;
  letter-spacing: 0.8px;
}
.field input, .field select {
  background: var(--surface2);
  border: 1px solid var(--border);
  border-radius: 8px;
  padding: 10px 14px;
  color: var(--text);
  font-family: var(--font-mono);
  font-size: 13px;
  outline: none;
  transition: border-color 0.2s, box-shadow 0.2s;
  width: 100%;
}
.field input:focus, .field select:focus {
  border-color: var(--accent);
  box-shadow: 0 0 0 3px rgba(0,229,255,0.1);
}
.field select option { background: var(--surface2); }

/* Button */
.btn {
  padding: 11px 24px;
  border-radius: 8px;
  font-family: var(--font-mono);
  font-size: 13px;
  font-weight: 700;
  cursor: pointer;
  border: none;
  transition: all 0.2s;
  display: inline-flex;
  align-items: center;
  gap: 8px;
  letter-spacing: 0.5px;
}
.btn-primary {
  background: var(--accent);
  color: #000;
}
.btn-primary:hover {
  background: #33eeff;
  box-shadow: 0 0 20px rgba(0,229,255,0.4);
  transform: translateY(-1px);
}
.btn-danger {
  background: var(--red);
  color: #fff;
}
.btn-danger:hover {
  background: #ff6680;
  box-shadow: 0 0 20px rgba(255,68,102,0.4);
}
.btn-sm { padding: 6px 14px; font-size: 12px; }
.btn:disabled { opacity:0.5; cursor:not-allowed; transform:none !important; }

/* Result box */
.result-box {
  margin-top: 16px;
  background: var(--surface2);
  border: 1px solid var(--border);
  border-radius: 10px;
  overflow: hidden;
  display: none;
}
.result-box.show { display: block; animation: fadeIn 0.3s ease; }
.result-header {
  padding: 10px 16px;
  background: rgba(0,229,255,0.06);
  border-bottom: 1px solid var(--border);
  font-size: 11px;
  font-weight: 700;
  color: var(--accent);
  text-transform: uppercase;
  letter-spacing: 1px;
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.result-body { padding: 16px; }
.result-row {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 8px 0;
  border-bottom: 1px solid rgba(255,255,255,0.04);
  gap: 12px;
}
.result-row:last-child { border-bottom: none; }
.result-key { font-size:11px; color: var(--muted); flex-shrink:0; width:120px; }
.result-val {
  font-size:13px;
  color: var(--text);
  word-break: break-all;
  flex:1;
}
.copy-btn {
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius:5px;
  padding: 4px 10px;
  color: var(--muted);
  font-size:11px;
  font-family: var(--font-mono);
  cursor:pointer;
  transition: all 0.2s;
  flex-shrink:0;
}
.copy-btn:hover { border-color:var(--accent); color:var(--accent); }
.copy-btn.copied { border-color:var(--green); color:var(--green); }

/* Config link full */
.config-full {
  margin-top:12px;
  background: #0d0d16;
  border: 1px solid var(--border);
  border-radius:8px;
  padding:12px;
  font-size:12px;
  color: var(--accent);
  word-break:break-all;
  line-height:1.6;
  position:relative;
}
.config-full .copy-all {
  position:absolute;
  top:8px; right:8px;
  background: var(--surface2);
  border: 1px solid var(--border);
  border-radius:5px;
  padding: 4px 10px;
  color: var(--muted);
  font-size:11px;
  font-family: var(--font-mono);
  cursor:pointer;
  transition: all 0.2s;
}
.config-full .copy-all:hover { border-color:var(--accent); color:var(--accent); }

/* Alert */
.alert {
  padding: 12px 16px;
  border-radius: 8px;
  font-size: 13px;
  margin-top: 12px;
  display: none;
}
.alert.show { display:block; animation: fadeIn 0.3s; }
.alert-error { background:rgba(255,68,102,0.1); border:1px solid rgba(255,68,102,0.3); color:var(--red); }
.alert-success { background:rgba(0,255,136,0.08); border:1px solid rgba(0,255,136,0.3); color:var(--green); }

/* User list table */
.user-table { width:100%; border-collapse:collapse; font-size:13px; }
.user-table th {
  text-align:left;
  padding:10px 14px;
  font-size:11px;
  font-weight:700;
  color:var(--muted);
  text-transform:uppercase;
  letter-spacing:0.8px;
  border-bottom:1px solid var(--border);
}
.user-table td {
  padding:11px 14px;
  border-bottom:1px solid rgba(255,255,255,0.04);
  vertical-align:middle;
}
.user-table tr:hover td { background:rgba(255,255,255,0.02); }
.badge {
  display:inline-block;
  padding:3px 10px;
  border-radius:20px;
  font-size:11px;
  font-weight:700;
}
.badge-green { background:rgba(0,255,136,0.12); color:var(--green); }
.badge-red { background:rgba(255,68,102,0.12); color:var(--red); }
.badge-yellow { background:rgba(255,204,0,0.12); color:var(--yellow); }

/* Stats */
.stats-grid {
  display:grid;
  grid-template-columns:repeat(auto-fit, minmax(180px, 1fr));
  gap:12px;
  margin-bottom:24px;
}
.stat-card {
  background: var(--surface);
  border: 1px solid var(--border);
  border-radius:10px;
  padding:16px;
  position:relative;
  overflow:hidden;
}
.stat-card::after {
  content:'';
  position:absolute;
  top:0; left:0; right:0;
  height:2px;
}
.stat-card.cyan::after { background: var(--accent); }
.stat-card.purple::after { background: var(--accent2); }
.stat-card.green::after { background: var(--green); }
.stat-card.yellow::after { background: var(--yellow); }
.stat-label { font-size:11px; color:var(--muted); text-transform:uppercase; letter-spacing:0.8px; margin-bottom:8px; }
.stat-value { font-family:var(--font-display); font-size:28px; font-weight:800; }
.stat-card.cyan .stat-value { color:var(--accent); }
.stat-card.purple .stat-value { color:#a78bfa; }
.stat-card.green .stat-value { color:var(--green); }
.stat-card.yellow .stat-value { color:var(--yellow); }

/* Loading spinner */
.spinner {
  width:16px; height:16px;
  border:2px solid rgba(0,0,0,0.3);
  border-top-color:#000;
  border-radius:50%;
  animation:spin 0.6s linear infinite;
  display:none;
}
.btn-primary .spinner { border-color:rgba(0,0,0,0.3); border-top-color:#000; }
@keyframes spin { to { transform:rotate(360deg); } }

/* Scrollbar */
::-webkit-scrollbar { width:6px; height:6px; }
::-webkit-scrollbar-track { background:var(--bg); }
::-webkit-scrollbar-thumb { background:var(--border); border-radius:3px; }
::-webkit-scrollbar-thumb:hover { background:var(--muted); }
</style>
</head>
<body>

<div class="header">
  <div class="logo">VPN<span>Panel</span></div>
  <div class="server-info">
    <div class="dot"></div>
    <span id="server-ip">Loading...</span>
  </div>
</div>

<div class="container">

  <!-- Stats -->
  <div class="stats-grid">
    <div class="stat-card cyan">
      <div class="stat-label">SSH Users</div>
      <div class="stat-value" id="stat-ssh">—</div>
    </div>
    <div class="stat-card purple">
      <div class="stat-label">Xray Users</div>
      <div class="stat-value" id="stat-xray">—</div>
    </div>
    <div class="stat-card green">
      <div class="stat-label">RAM Usage</div>
      <div class="stat-value" id="stat-ram">—</div>
    </div>
    <div class="stat-card yellow">
      <div class="stat-label">Uptime</div>
      <div class="stat-value" id="stat-uptime">—</div>
    </div>
  </div>

  <!-- Tabs -->
  <div class="tabs">
    <button class="tab active" onclick="switchTab('ssh')">SSH</button>
    <button class="tab" onclick="switchTab('vmess')">Vmess</button>
    <button class="tab" onclick="switchTab('vless')">Vless</button>
    <button class="tab" onclick="switchTab('trojan')">Trojan</button>
    <button class="tab" onclick="switchTab('shadowsocks')">Shadowsocks</button>
    <button class="tab" onclick="switchTab('users')">User List</button>
    <button class="tab" onclick="switchTab('service')">Services</button>
  </div>

  <!-- SSH Panel -->
  <div id="panel-ssh" class="panel active">
    <div class="card">
      <div class="card-title">Create SSH Account</div>
      <div class="form-row triple">
        <div class="field">
          <label>Username</label>
          <input type="text" id="ssh-user" placeholder="e.g. user01">
        </div>
        <div class="field">
          <label>Password</label>
          <input type="text" id="ssh-pass" placeholder="e.g. pass123">
        </div>
        <div class="field">
          <label>Expired (days)</label>
          <input type="number" id="ssh-exp" placeholder="30" value="30" min="1">
        </div>
      </div>
      <button class="btn btn-primary" onclick="createSSH()">
        <div class="spinner" id="ssh-spin"></div>
        ⚡ Create SSH
      </button>
      <div class="alert alert-error" id="ssh-error"></div>
      <div class="result-box" id="ssh-result">
        <div class="result-header">
          <span>✅ SSH Account Created</span>
          <button class="copy-btn" onclick="copyAll('ssh-result-content')">Copy All</button>
        </div>
        <div class="result-body" id="ssh-result-content"></div>
      </div>
    </div>
  </div>

  <!-- Vmess Panel -->
  <div id="panel-vmess" class="panel">
    <div class="card">
      <div class="card-title">Create Vmess Account</div>
      <div class="form-row">
        <div class="field">
          <label>Username</label>
          <input type="text" id="vmess-user" placeholder="e.g. user01">
        </div>
        <div class="field">
          <label>Expired (days)</label>
          <input type="number" id="vmess-exp" placeholder="30" value="30" min="1">
        </div>
      </div>
      <button class="btn btn-primary" onclick="createVmess()">
        <div class="spinner" id="vmess-spin"></div>
        ⚡ Create Vmess
      </button>
      <div class="alert alert-error" id="vmess-error"></div>
      <div class="result-box" id="vmess-result">
        <div class="result-header">
          <span>✅ Vmess Account Created</span>
        </div>
        <div class="result-body" id="vmess-result-content"></div>
      </div>
    </div>
  </div>

  <!-- Vless Panel -->
  <div id="panel-vless" class="panel">
    <div class="card">
      <div class="card-title">Create Vless Account</div>
      <div class="form-row">
        <div class="field">
          <label>Username</label>
          <input type="text" id="vless-user" placeholder="e.g. user01">
        </div>
        <div class="field">
          <label>Expired (days)</label>
          <input type="number" id="vless-exp" placeholder="30" value="30" min="1">
        </div>
      </div>
      <button class="btn btn-primary" onclick="createVless()">
        <div class="spinner" id="vless-spin"></div>
        ⚡ Create Vless
      </button>
      <div class="alert alert-error" id="vless-error"></div>
      <div class="result-box" id="vless-result">
        <div class="result-header">
          <span>✅ Vless Account Created</span>
        </div>
        <div class="result-body" id="vless-result-content"></div>
      </div>
    </div>
  </div>

  <!-- Trojan Panel -->
  <div id="panel-trojan" class="panel">
    <div class="card">
      <div class="card-title">Create Trojan Account</div>
      <div class="form-row">
        <div class="field">
          <label>Username</label>
          <input type="text" id="trojan-user" placeholder="e.g. user01">
        </div>
        <div class="field">
          <label>Expired (days)</label>
          <input type="number" id="trojan-exp" placeholder="30" value="30" min="1">
        </div>
      </div>
      <button class="btn btn-primary" onclick="createTrojan()">
        <div class="spinner" id="trojan-spin"></div>
        ⚡ Create Trojan
      </button>
      <div class="alert alert-error" id="trojan-error"></div>
      <div class="result-box" id="trojan-result">
        <div class="result-header">
          <span>✅ Trojan Account Created</span>
        </div>
        <div class="result-body" id="trojan-result-content"></div>
      </div>
    </div>
  </div>

  <!-- Shadowsocks Panel -->
  <div id="panel-shadowsocks" class="panel">
    <div class="card">
      <div class="card-title">Create Shadowsocks Account</div>
      <div class="form-row">
        <div class="field">
          <label>Username</label>
          <input type="text" id="ss-user" placeholder="e.g. user01">
        </div>
        <div class="field">
          <label>Expired (days)</label>
          <input type="number" id="ss-exp" placeholder="30" value="30" min="1">
        </div>
      </div>
      <button class="btn btn-primary" onclick="createSS()">
        <div class="spinner" id="ss-spin"></div>
        ⚡ Create Shadowsocks
      </button>
      <div class="alert alert-error" id="ss-error"></div>
      <div class="result-box" id="ss-result">
        <div class="result-header">
          <span>✅ Shadowsocks Account Created</span>
        </div>
        <div class="result-body" id="ss-result-content"></div>
      </div>
    </div>
  </div>

  <!-- User List Panel -->
  <div id="panel-users" class="panel">
    <div class="card">
      <div class="card-title">SSH User List</div>
      <div id="ssh-user-list"><div style="color:var(--muted);font-size:13px;">Loading...</div></div>
    </div>
    <div class="card">
      <div class="card-title">Xray User List</div>
      <div id="xray-user-list"><div style="color:var(--muted);font-size:13px;">Loading...</div></div>
    </div>
  </div>

  <!-- Services Panel -->
  <div id="panel-service" class="panel">
    <div class="card">
      <div class="card-title">Service Status</div>
      <div id="service-list"><div style="color:var(--muted);font-size:13px;">Loading...</div></div>
    </div>
    <div class="card">
      <div class="card-title">Quick Actions</div>
      <div style="display:flex;flex-wrap:wrap;gap:10px;">
        <button class="btn btn-primary btn-sm" onclick="restartService('xray')">↻ Restart Xray</button>
        <button class="btn btn-primary btn-sm" onclick="restartService('nginx')">↻ Restart Nginx</button>
        <button class="btn btn-primary btn-sm" onclick="restartService('ssh')">↻ Restart SSH</button>
        <button class="btn btn-primary btn-sm" onclick="restartService('dropbear')">↻ Restart Dropbear</button>
        <button class="btn btn-primary btn-sm" onclick="restartService('stunnel4')">↻ Restart Stunnel4</button>
        <button class="btn btn-danger btn-sm" onclick="clearCache()">🧹 Clear RAM Cache</button>
      </div>
      <div class="alert" id="service-alert" style="margin-top:12px;"></div>
    </div>
  </div>

</div>

<script>
// ============================================================
// Tab switching
// ============================================================
function switchTab(name) {
  document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
  document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
  event.target.classList.add('active');
  document.getElementById('panel-' + name).classList.add('active');
  if (name === 'users') loadUsers();
  if (name === 'service') loadServices();
}

// ============================================================
// API helper
// ============================================================
async function api(action, data = {}) {
  const res = await fetch('api.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ action, ...data })
  });
  return res.json();
}

// ============================================================
// Loading state
// ============================================================
function setLoading(spinId, btnEl, loading) {
  const spin = document.getElementById(spinId);
  if (loading) {
    spin.style.display = 'block';
    btnEl.disabled = true;
  } else {
    spin.style.display = 'none';
    btnEl.disabled = false;
  }
}

// ============================================================
// Copy helpers
// ============================================================
function copyText(text, btn) {
  navigator.clipboard.writeText(text).then(() => {
    const orig = btn.textContent;
    btn.textContent = 'Copied!';
    btn.classList.add('copied');
    setTimeout(() => { btn.textContent = orig; btn.classList.remove('copied'); }, 2000);
  });
}

function copyAll(containerId) {
  const rows = document.querySelectorAll('#' + containerId + ' .result-val');
  let text = '';
  rows.forEach(r => { text += r.textContent + '\n'; });
  navigator.clipboard.writeText(text.trim()).then(() => {
    const btn = event.target;
    btn.textContent = 'Copied!';
    setTimeout(() => btn.textContent = 'Copy All', 2000);
  });
}

// ============================================================
// Render result rows
// ============================================================
function renderRows(containerId, rows) {
  const el = document.getElementById(containerId);
  el.innerHTML = rows.map(r => `
    <div class="result-row">
      <div class="result-key">${r.key}</div>
      <div class="result-val">${r.val}</div>
      ${r.copy !== false ? `<button class="copy-btn" onclick="copyText('${r.val.replace(/'/g,"\\'")}', this)">Copy</button>` : ''}
    </div>
  `).join('');
}

function renderConfig(containerId, config) {
  const el = document.getElementById(containerId);
  el.innerHTML += `
    <div class="config-full">
      <button class="copy-all" onclick="copyText('${config.replace(/'/g,"\\'")}', this)">Copy</button>
      ${config}
    </div>
  `;
}

// ============================================================
// SSH
// ============================================================
async function createSSH() {
  const user = document.getElementById('ssh-user').value.trim();
  const pass = document.getElementById('ssh-pass').value.trim();
  const exp  = document.getElementById('ssh-exp').value.trim();
  const errEl = document.getElementById('ssh-error');
  const btn = event.target.closest('button');

  errEl.classList.remove('show');
  if (!user || !pass || !exp) {
    errEl.textContent = 'Semua field wajib diisi!';
    errEl.classList.add('show');
    return;
  }

  setLoading('ssh-spin', btn, true);
  const res = await api('create_ssh', { user, pass, exp });
  setLoading('ssh-spin', btn, false);

  if (!res.success) {
    errEl.textContent = res.message || 'Gagal membuat akun SSH';
    errEl.classList.add('show');
    return;
  }

  const d = res.data;
  renderRows('ssh-result-content', [
    { key: 'Username',  val: d.user },
    { key: 'Password',  val: d.pass },
    { key: 'Expired',   val: d.exp + ' days' },
    { key: 'Host',      val: d.host },
    { key: 'Port SSH',  val: '22 / 9696' },
    { key: 'Port WS',   val: '80 (HTTP)' },
    { key: 'Port WSS',  val: '443 (HTTPS)' },
    { key: 'Dropbear',  val: '109 / 143' },
    { key: 'Stunnel',   val: '222 / 777' },
    { key: 'BadVPN',    val: '7100-7400', copy: false },
  ]);
  document.getElementById('ssh-result').classList.add('show');
  loadStats();
}

// ============================================================
// Vmess
// ============================================================
async function createVmess() {
  const user = document.getElementById('vmess-user').value.trim();
  const exp  = document.getElementById('vmess-exp').value.trim();
  const errEl = document.getElementById('vmess-error');
  const btn = event.target.closest('button');

  errEl.classList.remove('show');
  if (!user || !exp) { errEl.textContent = 'Semua field wajib diisi!'; errEl.classList.add('show'); return; }

  setLoading('vmess-spin', btn, true);
  const res = await api('create_vmess', { user, exp });
  setLoading('vmess-spin', btn, false);

  if (!res.success) { errEl.textContent = res.message || 'Gagal'; errEl.classList.add('show'); return; }

  const d = res.data;
  renderRows('vmess-result-content', [
    { key: 'Username', val: d.user },
    { key: 'UUID',     val: d.uuid },
    { key: 'Domain',   val: d.host },
    { key: 'Port TLS', val: '443' },
    { key: 'Port HTTP',val: '80' },
    { key: 'Network',  val: 'WebSocket' },
    { key: 'Path',     val: '/vmess' },
    { key: 'Expired',  val: d.exp + ' days' },
  ]);
  renderConfig('vmess-result-content', d.link_tls);
  document.getElementById('vmess-result').classList.add('show');
  loadStats();
}

// ============================================================
// Vless
// ============================================================
async function createVless() {
  const user = document.getElementById('vless-user').value.trim();
  const exp  = document.getElementById('vless-exp').value.trim();
  const errEl = document.getElementById('vless-error');
  const btn = event.target.closest('button');

  errEl.classList.remove('show');
  if (!user || !exp) { errEl.textContent = 'Semua field wajib diisi!'; errEl.classList.add('show'); return; }

  setLoading('vless-spin', btn, true);
  const res = await api('create_vless', { user, exp });
  setLoading('vless-spin', btn, false);

  if (!res.success) { errEl.textContent = res.message || 'Gagal'; errEl.classList.add('show'); return; }

  const d = res.data;
  renderRows('vless-result-content', [
    { key: 'Username', val: d.user },
    { key: 'UUID',     val: d.uuid },
    { key: 'Domain',   val: d.host },
    { key: 'Port TLS', val: '443' },
    { key: 'Port HTTP',val: '80' },
    { key: 'Network',  val: 'WebSocket' },
    { key: 'Path',     val: '/vless' },
    { key: 'Expired',  val: d.exp + ' days' },
  ]);
  renderConfig('vless-result-content', d.link_tls);
  document.getElementById('vless-result').classList.add('show');
  loadStats();
}

// ============================================================
// Trojan
// ============================================================
async function createTrojan() {
  const user = document.getElementById('trojan-user').value.trim();
  const exp  = document.getElementById('trojan-exp').value.trim();
  const errEl = document.getElementById('trojan-error');
  const btn = event.target.closest('button');

  errEl.classList.remove('show');
  if (!user || !exp) { errEl.textContent = 'Semua field wajib diisi!'; errEl.classList.add('show'); return; }

  setLoading('trojan-spin', btn, true);
  const res = await api('create_trojan', { user, exp });
  setLoading('trojan-spin', btn, false);

  if (!res.success) { errEl.textContent = res.message || 'Gagal'; errEl.classList.add('show'); return; }

  const d = res.data;
  renderRows('trojan-result-content', [
    { key: 'Username', val: d.user },
    { key: 'Password', val: d.pass },
    { key: 'Domain',   val: d.host },
    { key: 'Port TLS', val: '443' },
    { key: 'Port HTTP',val: '80' },
    { key: 'Network',  val: 'WebSocket' },
    { key: 'Path',     val: '/trojan-ws' },
    { key: 'Expired',  val: d.exp + ' days' },
  ]);
  renderConfig('trojan-result-content', d.link_tls);
  document.getElementById('trojan-result').classList.add('show');
  loadStats();
}

// ============================================================
// Shadowsocks
// ============================================================
async function createSS() {
  const user = document.getElementById('ss-user').value.trim();
  const exp  = document.getElementById('ss-exp').value.trim();
  const errEl = document.getElementById('ss-error');
  const btn = event.target.closest('button');

  errEl.classList.remove('show');
  if (!user || !exp) { errEl.textContent = 'Semua field wajib diisi!'; errEl.classList.add('show'); return; }

  setLoading('ss-spin', btn, true);
  const res = await api('create_ss', { user, exp });
  setLoading('ss-spin', btn, false);

  if (!res.success) { errEl.textContent = res.message || 'Gagal'; errEl.classList.add('show'); return; }

  const d = res.data;
  renderRows('ss-result-content', [
    { key: 'Username', val: d.user },
    { key: 'Password', val: d.pass },
    { key: 'Domain',   val: d.host },
    { key: 'Port TLS', val: '443' },
    { key: 'Method',   val: 'aes-128-gcm' },
    { key: 'Path',     val: '/ss-ws' },
    { key: 'Expired',  val: d.exp + ' days' },
  ]);
  renderConfig('ss-result-content', d.link_tls);
  document.getElementById('ss-result').classList.add('show');
  loadStats();
}

// ============================================================
// Load stats
// ============================================================
async function loadStats() {
  try {
    const res = await api('stats');
    if (res.success) {
      document.getElementById('stat-ssh').textContent = res.data.ssh_users;
      document.getElementById('stat-xray').textContent = res.data.xray_users;
      document.getElementById('stat-ram').textContent = res.data.ram;
      document.getElementById('stat-uptime').textContent = res.data.uptime;
      document.getElementById('server-ip').textContent = res.data.ip;
    }
  } catch(e) {}
}

// ============================================================
// Load users
// ============================================================
async function loadUsers() {
  const res = await api('list_users');
  if (!res.success) return;

  // SSH users
  const sshEl = document.getElementById('ssh-user-list');
  if (res.data.ssh.length === 0) {
    sshEl.innerHTML = '<div style="color:var(--muted);font-size:13px;padding:8px 0;">Tidak ada user SSH</div>';
  } else {
    sshEl.innerHTML = `<table class="user-table">
      <thead><tr><th>Username</th><th>Expired</th><th>Status</th><th>Action</th></tr></thead>
      <tbody>
        ${res.data.ssh.map(u => `
          <tr>
            <td>${u.user}</td>
            <td>${u.exp}</td>
            <td><span class="badge ${u.status === 'active' ? 'badge-green' : 'badge-red'}">${u.status}</span></td>
            <td><button class="btn btn-danger btn-sm" onclick="deleteSSH('${u.user}')">Delete</button></td>
          </tr>
        `).join('')}
      </tbody>
    </table>`;
  }

  // Xray users
  const xrayEl = document.getElementById('xray-user-list');
  if (res.data.xray.length === 0) {
    xrayEl.innerHTML = '<div style="color:var(--muted);font-size:13px;padding:8px 0;">Tidak ada user Xray</div>';
  } else {
    xrayEl.innerHTML = `<table class="user-table">
      <thead><tr><th>Username</th><th>Type</th><th>Expired</th><th>Action</th></tr></thead>
      <tbody>
        ${res.data.xray.map(u => `
          <tr>
            <td>${u.user}</td>
            <td><span class="badge badge-yellow">${u.type}</span></td>
            <td>${u.exp}</td>
            <td><button class="btn btn-danger btn-sm" onclick="deleteXray('${u.user}','${u.type}')">Delete</button></td>
          </tr>
        `).join('')}
      </tbody>
    </table>`;
  }
}

// ============================================================
// Load services
// ============================================================
async function loadServices() {
  const res = await api('service_status');
  if (!res.success) return;
  const el = document.getElementById('service-list');
  el.innerHTML = `<table class="user-table">
    <thead><tr><th>Service</th><th>Status</th><th>Port</th></tr></thead>
    <tbody>
      ${res.data.map(s => `
        <tr>
          <td>${s.name}</td>
          <td><span class="badge ${s.status === 'running' ? 'badge-green' : 'badge-red'}">${s.status}</span></td>
          <td style="color:var(--muted)">${s.port}</td>
        </tr>
      `).join('')}
    </tbody>
  </table>`;
}

// ============================================================
// Delete actions
// ============================================================
async function deleteSSH(user) {
  if (!confirm('Hapus user SSH: ' + user + '?')) return;
  const res = await api('delete_ssh', { user });
  alert(res.message);
  loadUsers();
  loadStats();
}

async function deleteXray(user, type) {
  if (!confirm('Hapus user ' + type + ': ' + user + '?')) return;
  const res = await api('delete_xray', { user, type });
  alert(res.message);
  loadUsers();
  loadStats();
}

// ============================================================
// Service actions
// ============================================================
async function restartService(name) {
  const alertEl = document.getElementById('service-alert');
  alertEl.className = 'alert';
  alertEl.textContent = 'Restarting ' + name + '...';
  alertEl.classList.add('show');
  const res = await api('restart_service', { name });
  alertEl.className = 'alert ' + (res.success ? 'alert-success' : 'alert-error') + ' show';
  alertEl.textContent = res.message;
  setTimeout(() => { alertEl.classList.remove('show'); }, 3000);
  loadServices();
}

async function clearCache() {
  const alertEl = document.getElementById('service-alert');
  const res = await api('clear_cache');
  alertEl.className = 'alert ' + (res.success ? 'alert-success' : 'alert-error') + ' show';
  alertEl.textContent = res.message;
  setTimeout(() => { alertEl.classList.remove('show'); }, 3000);
  loadStats();
}

// Init
loadStats();
setInterval(loadStats, 30000);
</script>
</body>
</html>
