<?php
// ============================================================
// VPN Panel API - api.php
// Letakkan file ini di /home/vps/public_html/api.php
// ============================================================
header('Content-Type: application/json');
header('X-Content-Type-Options: nosniff');

// ============================================================
// KONFIGURASI - Sesuaikan dengan VPS Anda
// ============================================================
define('DOMAIN_FILE', '/etc/xray/domain');
define('SSH_LOG',     '/etc/log-create-ssh.log');
define('VMESS_LOG',   '/etc/log-create-vmess.log');
define('VLESS_LOG',   '/etc/log-create-vless.log');
define('TROJAN_LOG',  '/etc/log-create-trojan.log');
define('SS_LOG',      '/etc/log-create-shadowsocks.log');
define('XRAY_CONFIG', '/etc/xray/config.json');
define('MY_IP_FILE',  '/etc/myipvps');

// ============================================================
// Helper functions
// ============================================================
function ok($data = [], $message = 'OK') {
    echo json_encode(['success' => true, 'message' => $message, 'data' => $data]);
    exit;
}
function fail($message = 'Error') {
    echo json_encode(['success' => false, 'message' => $message, 'data' => null]);
    exit;
}
function runCmd($cmd) {
    $output = shell_exec($cmd . ' 2>&1');
    return trim($output ?? '');
}
function getDomain() {
    if (file_exists(DOMAIN_FILE)) return trim(file_get_contents(DOMAIN_FILE));
    return runCmd('cat /etc/myipvps');
}
function getIP() {
    if (file_exists(MY_IP_FILE)) return trim(file_get_contents(MY_IP_FILE));
    return runCmd('curl -s ifconfig.me');
}
function validateUser($user) {
    return preg_match('/^[a-zA-Z0-9_\-]{3,20}$/', $user);
}
function generatePassword($len = 8) {
    $chars = 'abcdefghjkmnpqrstuvwxyzABCDEFGHJKMNPQRSTUVWXYZ23456789';
    $pass = '';
    for ($i = 0; $i < $len; $i++) $pass .= $chars[random_int(0, strlen($chars)-1)];
    return $pass;
}

// ============================================================
// Read request
// ============================================================
$input = json_decode(file_get_contents('php://input'), true) ?? [];
$action = $input['action'] ?? '';

// ============================================================
// ACTIONS
// ============================================================
switch ($action) {

// ------------------------------------------------------------
// STATS
// ------------------------------------------------------------
case 'stats':
    // SSH users count (non-system users)
    $ssh_users = (int) runCmd("awk -F: '\$3 >= 1000 && \$1 != \"nobody\" {print \$1}' /etc/passwd | wc -l");

    // Xray users count (dari config.json)
    $xray_users = 0;
    if (file_exists(XRAY_CONFIG)) {
        $cfg = json_decode(file_get_contents(XRAY_CONFIG), true);
        foreach ($cfg['inbounds'] ?? [] as $inbound) {
            $clients = $inbound['settings']['clients'] ?? [];
            $xray_users += count($clients);
        }
    }

    // RAM usage
    $mem_total = (int) runCmd("grep MemTotal /proc/meminfo | awk '{print \$2}'");
    $mem_avail = (int) runCmd("grep MemAvailable /proc/meminfo | awk '{print \$2}'");
    $mem_used  = round(($mem_total - $mem_avail) / 1024);
    $mem_total_mb = round($mem_total / 1024);
    $ram_str = $mem_used . '/' . $mem_total_mb . 'MB';

    // Uptime
    $uptime_raw = (int) runCmd("cat /proc/uptime | awk '{print int(\$1)}'");
    $days  = intdiv($uptime_raw, 86400);
    $hours = intdiv($uptime_raw % 86400, 3600);
    $uptime_str = $days > 0 ? "{$days}d {$hours}h" : "{$hours}h";

    ok([
        'ssh_users'  => $ssh_users,
        'xray_users' => $xray_users,
        'ram'        => $ram_str,
        'uptime'     => $uptime_str,
        'ip'         => getIP(),
    ]);

// ------------------------------------------------------------
// CREATE SSH
// ------------------------------------------------------------
case 'create_ssh':
    $user = $input['user'] ?? '';
    $pass = $input['pass'] ?? '';
    $exp  = (int)($input['exp'] ?? 30);
    $host = getDomain();

    if (!validateUser($user)) fail('Username tidak valid (3-20 karakter, huruf/angka/_-)');
    if (strlen($pass) < 4)    fail('Password minimal 4 karakter');
    if ($exp < 1 || $exp > 365) fail('Expired tidak valid (1-365 hari)');

    // Cek apakah user sudah ada
    $check = runCmd("id $user 2>/dev/null");
    if (!empty($check)) fail("User '$user' sudah ada!");

    // Hitung tanggal expired
    $exp_date = date('Y-m-d', strtotime("+{$exp} days"));

    // Buat user SSH
    $result = runCmd("useradd -e $exp_date -s /bin/false -M $user 2>&1");
    runCmd("echo '$user:$pass' | chpasswd 2>&1");

    // Log
    $log = date('Y-m-d H:i:s') . " | user: $user | pass: $pass | exp: $exp_date\n";
    file_put_contents(SSH_LOG, $log, FILE_APPEND);

    ok([
        'user' => $user,
        'pass' => $pass,
        'exp'  => $exp,
        'exp_date' => $exp_date,
        'host' => $host,
    ], 'SSH account created');

// ------------------------------------------------------------
// CREATE VMESS
// ------------------------------------------------------------
case 'create_vmess':
    $user = $input['user'] ?? '';
    $exp  = (int)($input['exp'] ?? 30);
    $host = getDomain();

    if (!validateUser($user)) fail('Username tidak valid');
    if ($exp < 1 || $exp > 365) fail('Expired tidak valid');

    // Generate UUID
    $uuid = runCmd('cat /proc/sys/kernel/random/uuid');
    if (empty($uuid)) fail('Gagal generate UUID');

    $exp_date = date('Y-m-d', strtotime("+{$exp} days"));

    // Tambah ke xray config
    if (!file_exists(XRAY_CONFIG)) fail('Xray config tidak ditemukan');
    $cfg = json_decode(file_get_contents(XRAY_CONFIG), true);
    if (!$cfg) fail('Xray config tidak valid');

    $added = false;
    foreach ($cfg['inbounds'] as &$inbound) {
        if (($inbound['protocol'] ?? '') === 'vmess' && ($inbound['streamSettings']['network'] ?? '') === 'ws') {
            $inbound['settings']['clients'][] = [
                'id'      => $uuid,
                'alterId' => 0,
                'email'   => $user . '@vmess',
            ];
            $added = true;
            break;
        }
    }
    if (!$added) fail('Vmess inbound tidak ditemukan di config');

    file_put_contents(XRAY_CONFIG, json_encode($cfg, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
    runCmd('systemctl restart xray');

    // Build vmess link
    $vmess_obj = [
        'v'    => '2',
        'ps'   => $user,
        'add'  => $host,
        'port' => '443',
        'id'   => $uuid,
        'aid'  => '0',
        'net'  => 'ws',
        'type' => 'none',
        'host' => $host,
        'path' => '/vmess',
        'tls'  => 'tls',
        'sni'  => $host,
    ];
    $link_tls = 'vmess://' . base64_encode(json_encode($vmess_obj));

    $vmess_http = $vmess_obj;
    $vmess_http['port'] = '80';
    $vmess_http['tls']  = '';
    $link_http = 'vmess://' . base64_encode(json_encode($vmess_http));

    // Log
    $log = date('Y-m-d H:i:s') . " | user: $user | uuid: $uuid | exp: $exp_date\n";
    file_put_contents(VMESS_LOG, $log, FILE_APPEND);

    ok([
        'user'     => $user,
        'uuid'     => $uuid,
        'host'     => $host,
        'exp'      => $exp,
        'exp_date' => $exp_date,
        'link_tls' => $link_tls,
        'link_http'=> $link_http,
    ], 'Vmess account created');

// ------------------------------------------------------------
// CREATE VLESS
// ------------------------------------------------------------
case 'create_vless':
    $user = $input['user'] ?? '';
    $exp  = (int)($input['exp'] ?? 30);
    $host = getDomain();

    if (!validateUser($user)) fail('Username tidak valid');
    if ($exp < 1 || $exp > 365) fail('Expired tidak valid');

    $uuid = runCmd('cat /proc/sys/kernel/random/uuid');
    if (empty($uuid)) fail('Gagal generate UUID');
    $exp_date = date('Y-m-d', strtotime("+{$exp} days"));

    if (!file_exists(XRAY_CONFIG)) fail('Xray config tidak ditemukan');
    $cfg = json_decode(file_get_contents(XRAY_CONFIG), true);
    if (!$cfg) fail('Xray config tidak valid');

    $added = false;
    foreach ($cfg['inbounds'] as &$inbound) {
        if (($inbound['protocol'] ?? '') === 'vless' && ($inbound['streamSettings']['network'] ?? '') === 'ws') {
            $inbound['settings']['clients'][] = [
                'id'    => $uuid,
                'email' => $user . '@vless',
            ];
            $added = true;
            break;
        }
    }
    if (!$added) fail('Vless inbound tidak ditemukan di config');

    file_put_contents(XRAY_CONFIG, json_encode($cfg, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
    runCmd('systemctl restart xray');

    $link_tls  = "vless://{$uuid}@{$host}:443?encryption=none&security=tls&sni={$host}&type=ws&host={$host}&path=%2Fvless#{$user}";
    $link_http = "vless://{$uuid}@{$host}:80?encryption=none&security=none&type=ws&host={$host}&path=%2Fvless#{$user}";

    $log = date('Y-m-d H:i:s') . " | user: $user | uuid: $uuid | exp: $exp_date\n";
    file_put_contents(VLESS_LOG, $log, FILE_APPEND);

    ok([
        'user'     => $user,
        'uuid'     => $uuid,
        'host'     => $host,
        'exp'      => $exp,
        'exp_date' => $exp_date,
        'link_tls' => $link_tls,
        'link_http'=> $link_http,
    ], 'Vless account created');

// ------------------------------------------------------------
// CREATE TROJAN
// ------------------------------------------------------------
case 'create_trojan':
    $user = $input['user'] ?? '';
    $exp  = (int)($input['exp'] ?? 30);
    $host = getDomain();

    if (!validateUser($user)) fail('Username tidak valid');
    if ($exp < 1 || $exp > 365) fail('Expired tidak valid');

    $pass     = generatePassword(12);
    $exp_date = date('Y-m-d', strtotime("+{$exp} days"));

    if (!file_exists(XRAY_CONFIG)) fail('Xray config tidak ditemukan');
    $cfg = json_decode(file_get_contents(XRAY_CONFIG), true);
    if (!$cfg) fail('Xray config tidak valid');

    $added = false;
    foreach ($cfg['inbounds'] as &$inbound) {
        if (($inbound['protocol'] ?? '') === 'trojan' && ($inbound['streamSettings']['network'] ?? '') === 'ws') {
            $inbound['settings']['clients'][] = [
                'password' => $pass,
                'email'    => $user . '@trojan',
            ];
            $added = true;
            break;
        }
    }
    if (!$added) fail('Trojan inbound tidak ditemukan di config');

    file_put_contents(XRAY_CONFIG, json_encode($cfg, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
    runCmd('systemctl restart xray');

    $link_tls  = "trojan://{$pass}@{$host}:443?security=tls&sni={$host}&type=ws&host={$host}&path=%2Ftrojan-ws#{$user}";
    $link_http = "trojan://{$pass}@{$host}:80?security=none&type=ws&host={$host}&path=%2Ftrojan-ws#{$user}";

    $log = date('Y-m-d H:i:s') . " | user: $user | pass: $pass | exp: $exp_date\n";
    file_put_contents(TROJAN_LOG, $log, FILE_APPEND);

    ok([
        'user'     => $user,
        'pass'     => $pass,
        'host'     => $host,
        'exp'      => $exp,
        'exp_date' => $exp_date,
        'link_tls' => $link_tls,
        'link_http'=> $link_http,
    ], 'Trojan account created');

// ------------------------------------------------------------
// CREATE SHADOWSOCKS
// ------------------------------------------------------------
case 'create_ss':
    $user = $input['user'] ?? '';
    $exp  = (int)($input['exp'] ?? 30);
    $host = getDomain();

    if (!validateUser($user)) fail('Username tidak valid');
    if ($exp < 1 || $exp > 365) fail('Expired tidak valid');

    $pass     = generatePassword(12);
    $exp_date = date('Y-m-d', strtotime("+{$exp} days"));
    $method   = 'aes-128-gcm';

    if (!file_exists(XRAY_CONFIG)) fail('Xray config tidak ditemukan');
    $cfg = json_decode(file_get_contents(XRAY_CONFIG), true);
    if (!$cfg) fail('Xray config tidak valid');

    $added = false;
    foreach ($cfg['inbounds'] as &$inbound) {
        if (($inbound['protocol'] ?? '') === 'shadowsocks' && ($inbound['streamSettings']['network'] ?? '') === 'ws') {
            $inbound['settings']['clients'][] = [
                'method'   => $method,
                'password' => $pass,
                'email'    => $user . '@ss',
            ];
            $added = true;
            break;
        }
    }
    if (!$added) fail('Shadowsocks inbound tidak ditemukan di config');

    file_put_contents(XRAY_CONFIG, json_encode($cfg, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
    runCmd('systemctl restart xray');

    $ss_tls  = base64_encode("{$method}:{$pass}");
    $link_tls  = "ss://{$ss_tls}@{$host}:443?plugin=v2ray-plugin%3Btls%3Bmode%3Dwebsocket%3Bpath%3D%2Fss-ws%3Bhost%3D{$host}#{$user}";
    $link_http = "ss://{$ss_tls}@{$host}:80?plugin=v2ray-plugin%3Bmode%3Dwebsocket%3Bpath%3D%2Fss-ws%3Bhost%3D{$host}#{$user}";

    $log = date('Y-m-d H:i:s') . " | user: $user | pass: $pass | method: $method | exp: $exp_date\n";
    file_put_contents(SS_LOG, $log, FILE_APPEND);

    ok([
        'user'     => $user,
        'pass'     => $pass,
        'method'   => $method,
        'host'     => $host,
        'exp'      => $exp,
        'exp_date' => $exp_date,
        'link_tls' => $link_tls,
        'link_http'=> $link_http,
    ], 'Shadowsocks account created');

// ------------------------------------------------------------
// LIST USERS
// ------------------------------------------------------------
case 'list_users':
    // SSH users
    $ssh_raw = runCmd("awk -F: '\$3 >= 1000 && \$1 != \"nobody\" {print \$1\"|\"\$5\"|\"\$8}' /etc/passwd /etc/shadow 2>/dev/null");
    $ssh_users = [];
    $lines = explode("\n", runCmd("awk -F: '\$3 >= 1000 && \$1 != \"nobody\"' /etc/passwd"));
    foreach ($lines as $line) {
        $parts = explode(':', $line);
        if (count($parts) < 1 || empty($parts[0])) continue;
        $u = $parts[0];
        // Get expiry
        $exp_raw = runCmd("chage -l $u 2>/dev/null | grep 'Account expires' | awk -F: '{print \$2}'");
        $exp = trim($exp_raw) ?: 'never';
        // Check if account locked
        $lock = runCmd("passwd -S $u 2>/dev/null | awk '{print \$2}'");
        $status = ($lock === 'L' || $lock === 'LK') ? 'locked' : 'active';
        $ssh_users[] = ['user' => $u, 'exp' => $exp, 'status' => $status];
    }

    // Xray users from config
    $xray_users = [];
    if (file_exists(XRAY_CONFIG)) {
        $cfg = json_decode(file_get_contents(XRAY_CONFIG), true);
        foreach ($cfg['inbounds'] ?? [] as $inbound) {
            $proto = $inbound['protocol'] ?? '';
            $clients = $inbound['settings']['clients'] ?? [];
            foreach ($clients as $c) {
                $email = $c['email'] ?? '';
                $uname = preg_replace('/@.*/', '', $email) ?: 'unknown';
                $xray_users[] = [
                    'user' => $uname,
                    'type' => strtoupper($proto),
                    'exp'  => 'see log',
                ];
            }
        }
    }

    ok(['ssh' => $ssh_users, 'xray' => $xray_users]);

// ------------------------------------------------------------
// DELETE SSH
// ------------------------------------------------------------
case 'delete_ssh':
    $user = $input['user'] ?? '';
    if (!validateUser($user)) fail('Username tidak valid');
    $check = runCmd("id $user 2>/dev/null");
    if (empty($check)) fail("User '$user' tidak ditemukan");
    // Kick active sessions
    runCmd("pkill -u $user 2>/dev/null");
    runCmd("userdel -f $user 2>/dev/null");
    ok([], "User SSH '$user' berhasil dihapus");

// ------------------------------------------------------------
// DELETE XRAY
// ------------------------------------------------------------
case 'delete_xray':
    $user = $input['user'] ?? '';
    $type = strtolower($input['type'] ?? '');
    if (!validateUser($user)) fail('Username tidak valid');
    if (!file_exists(XRAY_CONFIG)) fail('Xray config tidak ditemukan');

    $cfg = json_decode(file_get_contents(XRAY_CONFIG), true);
    $deleted = false;
    foreach ($cfg['inbounds'] as &$inbound) {
        if (strtolower($inbound['protocol'] ?? '') !== $type) continue;
        $clients = $inbound['settings']['clients'] ?? [];
        $new_clients = array_filter($clients, function($c) use ($user, $type) {
            $email = $c['email'] ?? '';
            return !str_starts_with($email, $user . '@');
        });
        if (count($new_clients) < count($clients)) {
            $inbound['settings']['clients'] = array_values($new_clients);
            $deleted = true;
        }
    }

    if (!$deleted) fail("User '$user' tidak ditemukan di $type");
    file_put_contents(XRAY_CONFIG, json_encode($cfg, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
    runCmd('systemctl restart xray');
    ok([], "User $type '$user' berhasil dihapus");

// ------------------------------------------------------------
// SERVICE STATUS
// ------------------------------------------------------------
case 'service_status':
    $services = [
        ['name' => 'Xray',        'svc' => 'xray',            'port' => '443 / 80'],
        ['name' => 'Nginx',       'svc' => 'nginx',           'port' => '80 / 81 / 443'],
        ['name' => 'SSH',         'svc' => 'ssh',             'port' => '22 / 9696'],
        ['name' => 'Dropbear',    'svc' => 'dropbear',        'port' => '109 / 143'],
        ['name' => 'Stunnel4',    'svc' => 'stunnel4',        'port' => '222 / 777'],
        ['name' => 'WS-Dropbear', 'svc' => 'ws-dropbear',    'port' => '2095'],
        ['name' => 'WS-Stunnel',  'svc' => 'ws-stunnel',     'port' => '700'],
        ['name' => 'Fail2Ban',    'svc' => 'fail2ban',        'port' => '-'],
        ['name' => 'Vnstat',      'svc' => 'vnstat',          'port' => '-'],
        ['name' => 'Cron',        'svc' => 'cron',            'port' => '-'],
    ];
    $result = [];
    foreach ($services as $s) {
        $status = runCmd("systemctl is-active {$s['svc']} 2>/dev/null");
        $result[] = [
            'name'   => $s['name'],
            'status' => $status,
            'port'   => $s['port'],
        ];
    }
    ok($result);

// ------------------------------------------------------------
// RESTART SERVICE
// ------------------------------------------------------------
case 'restart_service':
    $name = $input['name'] ?? '';
    $allowed = ['xray','nginx','ssh','dropbear','stunnel4','ws-dropbear','ws-stunnel','fail2ban','vnstat','cron'];
    if (!in_array($name, $allowed)) fail('Service tidak diizinkan');
    runCmd("systemctl restart $name");
    $status = runCmd("systemctl is-active $name");
    if ($status === 'active') ok([], "$name berhasil direstart");
    else fail("$name gagal restart, status: $status");

// ------------------------------------------------------------
// CLEAR CACHE
// ------------------------------------------------------------
case 'clear_cache':
    runCmd('sync');
    runCmd('echo 3 > /proc/sys/vm/drop_caches');
    $mem_avail = (int) runCmd("grep MemAvailable /proc/meminfo | awk '{print \$2}'");
    $free_mb = round($mem_avail / 1024);
    ok([], "RAM cache cleared. Free: {$free_mb}MB");

default:
    fail('Action tidak dikenal');
}
