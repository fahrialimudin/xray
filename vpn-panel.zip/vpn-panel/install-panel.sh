#!/bin/bash
# ============================================================
# Install VPN Panel - Ubuntu 24.04
# Jalankan: bash install-panel.sh
# ============================================================

GREEN='\e[1;32m'
CYAN='\e[1;36m'
RED='\e[1;31m'
NC='\e[0m'

echo -e "${CYAN}=====================================${NC}"
echo -e "${CYAN}     Install VPN Panel              ${NC}"
echo -e "${CYAN}=====================================${NC}"

# Install PHP & PHP-FPM
echo -e "${GREEN}[1/5] Install PHP...${NC}"
apt update -y >/dev/null 2>&1
apt install -y php8.3 php8.3-fpm php8.3-cli php8.3-common >/dev/null 2>&1 || \
apt install -y php php-fpm php-cli php-common >/dev/null 2>&1

# Deteksi versi PHP
PHP_VER=$(php -r 'echo PHP_MAJOR_VERSION.".".PHP_MINOR_VERSION;' 2>/dev/null)
echo -e "${GREEN}   PHP version: $PHP_VER${NC}"

# Start PHP-FPM
echo -e "${GREEN}[2/5] Start PHP-FPM...${NC}"
systemctl enable php${PHP_VER}-fpm >/dev/null 2>&1
systemctl start php${PHP_VER}-fpm >/dev/null 2>&1

# Buat direktori panel
echo -e "${GREEN}[3/5] Setup panel files...${NC}"
mkdir -p /home/vps/public_html

# Copy file panel
cp /root/panel/index.php /home/vps/public_html/index.php
cp /root/panel/api.php   /home/vps/public_html/api.php

# Set permission agar PHP bisa jalankan system commands
chown -R www-data:www-data /home/vps/public_html
chmod 755 /home/vps/public_html

# Allow www-data untuk jalankan commands (sudoers)
echo -e "${GREEN}[4/5] Setup permissions...${NC}"
cat > /etc/sudoers.d/vpnpanel <<-EOF
www-data ALL=(ALL) NOPASSWD: /usr/sbin/useradd, /usr/sbin/userdel, /usr/bin/chpasswd, /usr/bin/chage, /usr/bin/passwd, /usr/bin/pkill, /bin/systemctl, /usr/bin/systemctl, /usr/sbin/chage, /bin/echo, /usr/bin/sync
EOF
chmod 440 /etc/sudoers.d/vpnpanel

# Tambahkan www-data ke sudoers untuk drop_caches
echo "www-data ALL=(ALL) NOPASSWD: /sbin/sysctl" >> /etc/sudoers.d/vpnpanel 2>/dev/null

# Konfigurasi Nginx untuk panel
echo -e "${GREEN}[5/5] Configure Nginx...${NC}"
DOMAIN=$(cat /etc/xray/domain 2>/dev/null || cat /etc/myipvps)

cat > /etc/nginx/conf.d/panel.conf <<-NGINXEOF
server {
    listen 8080;
    server_name _;
    root /home/vps/public_html;
    index index.php index.html;

    # Security: block direct access to api.php dari luar jika mau
    # Hapus block ini jika ingin api bisa diakses langsung
    
    location / {
        try_files \$uri \$uri/ /index.php?\$query_string;
    }

    location ~ \.php$ {
        include snippets/fastcgi-php.conf;
        fastcgi_pass unix:/run/php/php${PHP_VER}-fpm.sock;
        fastcgi_param SCRIPT_FILENAME \$document_root\$fastcgi_script_name;
        include fastcgi_params;
    }

    location ~ /\.ht {
        deny all;
    }
}
NGINXEOF

# Test dan reload nginx
nginx -t >/dev/null 2>&1 && systemctl reload nginx

echo -e ""
echo -e "${CYAN}=====================================${NC}"
echo -e "${CYAN}   Panel berhasil diinstall!        ${NC}"
echo -e "${CYAN}=====================================${NC}"
echo -e ""
echo -e "${GREEN} Akses panel di:${NC}"
echo -e " http://$DOMAIN:8080"
echo -e ""
echo -e "${GREEN} Atau jika pakai domain:${NC}"
echo -e " http://$DOMAIN:8080"
echo -e ""
echo -e "${CYAN}=====================================${NC}"
