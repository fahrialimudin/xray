#!/bin/bash
# ============================================================
# Install VPN Panel v2
# Jalankan: bash install-panel.sh
# ============================================================
GREEN='\e[1;32m'; CYAN='\e[1;36m'; RED='\e[1;31m'; NC='\e[0m'

echo -e "${CYAN}======================================${NC}"
echo -e "${CYAN}      Install VPN Panel v2           ${NC}"
echo -e "${CYAN}======================================${NC}"

# 1. Install PHP & FPM
echo -e "${GREEN}[1/6] Install PHP 8.3...${NC}"
apt update -y >/dev/null 2>&1
apt install -y php8.3 php8.3-fpm php8.3-cli php8.3-common >/dev/null 2>&1 || \
apt install -y php php-fpm php-cli php-common >/dev/null 2>&1

PHP_VER=$(php -r 'echo PHP_MAJOR_VERSION.".".PHP_MINOR_VERSION;' 2>/dev/null)
echo -e "${GREEN}   PHP versi: $PHP_VER${NC}"

# 2. Start PHP-FPM
echo -e "${GREEN}[2/6] Start PHP-FPM...${NC}"
systemctl enable php${PHP_VER}-fpm >/dev/null 2>&1
systemctl start  php${PHP_VER}-fpm >/dev/null 2>&1

# Cek socket
SOCK="/run/php/php${PHP_VER}-fpm.sock"
if [ ! -S "$SOCK" ]; then
  # fallback ke php-fpm.sock generic
  SOCK=$(ls /run/php/*.sock 2>/dev/null | head -1)
fi
echo -e "${GREEN}   Socket: $SOCK${NC}"

# 3. Setup folder dan file panel
echo -e "${GREEN}[3/6] Setup file panel...${NC}"
mkdir -p /home/vps/public_html
cp /root/panel/index.php /home/vps/public_html/index.php
cp /root/panel/api.php   /home/vps/public_html/api.php
chown -R www-data:www-data /home/vps/public_html
chmod 755 /home/vps/public_html
chmod 644 /home/vps/public_html/*.php

# 4. Sudoers untuk www-data
echo -e "${GREEN}[4/6] Setup sudoers...${NC}"
cat > /etc/sudoers.d/vpnpanel <<-EOF
www-data ALL=(ALL) NOPASSWD: ALL
EOF
chmod 440 /etc/sudoers.d/vpnpanel

# 5. Konfigurasi Nginx
echo -e "${GREEN}[5/6] Konfigurasi Nginx...${NC}"
DOMAIN=""
[ -f /etc/xray/domain ] && DOMAIN=$(cat /etc/xray/domain)
[ -z "$DOMAIN" ] && [ -f /etc/myipvps ] && DOMAIN=$(cat /etc/myipvps)
[ -z "$DOMAIN" ] && DOMAIN=$(curl -s ifconfig.me 2>/dev/null)
echo -e "${GREEN}   Domain/IP: $DOMAIN${NC}"

cat > /etc/nginx/conf.d/vpn-panel.conf <<-NGINXEOF
server {
    listen 8080;
    server_name _;
    root /home/vps/public_html;
    index index.php index.html;

    location / {
        try_files \$uri \$uri/ /index.php?\$query_string;
    }

    location ~ \.php\$ {
        include snippets/fastcgi-php.conf;
        fastcgi_pass unix:${SOCK};
        fastcgi_param SCRIPT_FILENAME \$document_root\$fastcgi_script_name;
        include fastcgi_params;
    }

    location ~ /\.ht {
        deny all;
    }
}
NGINXEOF

# Hapus config lama jika ada
rm -f /etc/nginx/conf.d/panel.conf

# 6. Reload Nginx
echo -e "${GREEN}[6/6] Reload Nginx...${NC}"
nginx -t >/dev/null 2>&1 && systemctl reload nginx

# Test API
echo -e "${GREEN}   Test API...${NC}"
sleep 1
RESULT=$(curl -s -X POST http://localhost:8080/api.php \
  -H "Content-Type: application/json" \
  -d '{"action":"stats"}')
if echo "$RESULT" | grep -q '"success":true'; then
  echo -e "${GREEN}   ✅ API berjalan normal!${NC}"
else
  echo -e "${RED}   ⚠️  API belum berjalan. Cek log: tail -20 /var/log/php${PHP_VER}-fpm.log${NC}"
fi

echo -e ""
echo -e "${CYAN}======================================${NC}"
echo -e "${CYAN}   Panel berhasil diinstall!         ${NC}"
echo -e "${CYAN}======================================${NC}"
echo -e ""
echo -e "${GREEN} Akses panel di:${NC}"
echo -e " http://${DOMAIN}:8080"
echo -e ""
echo -e "${CYAN}======================================${NC}"
