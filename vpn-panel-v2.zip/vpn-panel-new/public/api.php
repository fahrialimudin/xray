<?php
// ============================================================
// VPN Panel API v2 - api.php
// ============================================================
header('Content-Type: application/json');
header('X-Content-Type-Options: nosniff');

define('DOMAIN_FILE', '/etc/xray/domain');
define('SSH_LOG',     '/etc/log-create-ssh.log');
define('VMESS_LOG',   '/etc/log-create-vmess.log');
define('VLESS_LOG',   '/etc/log-create-vless.log');
define('TROJAN_LOG',  '/etc/log-create-trojan.log');
define('SS_LOG',      '/etc/log-create-shadowsocks.log');
define('XRAY_CONFIG', '/etc/xray/config.json');
define('MY_IP_FILE',  '/etc/myipvps');

function ok($data = [], $message = 'OK') {
    echo json_encode(['success' => true, 'message' => $message, 'data' => $data]);
    exit;
}
function fail($message = 'Error') {
    echo json_encode(['success' => false, 'message' => $message, 'data' => null]);
    exit;
}

// Semua perintah sistem pakai sudo agar www-data bisa eksekusi
function runCmd($cmd) {
    $output = shell_exec('sudo ' . $cmd . ' 2>&1');
    return trim($output ?? '');
}

function getDomain() {
    if (file_exists(DOMAIN_FILE)) return trim(file_get_contents(DOMAIN_FILE));
    if (file_exists(MY_IP_FILE)) return trim(file_get_contents(MY_IP_FILE));
    return runCmd('curl -s ifconfig.me');
}
function getIP() {
    if (file_exists(MY_IP_FILE)) return trim(file_get_contents(MY_IP_FILE));
    return runCmd('curl -s ifconfig.me');
}
function validateUser($user) {
    return preg_match('/^[a-zA-Z0-9_\-]{3,20}$/', $user);
}
function generatePassword($len = 10) {
    $chars = 'abcdefghjkmnpqrstuvwxyzABCDEFGHJKMNPQRSTUVWXYZ23456789';
    $pass = '';
    for ($i = 0; $i < $len; $i++) $pass .= $chars[random_int(0, strlen($chars)-1)];
    return $pass;
}

$input  = json_decode(file_get_contents('php://input'), true) ?? [];
$action = $input['action'] ?? '';

switch ($action) {

// ── STATS ────────────────────────────────────────────────
case 'stats':
    $ssh_users = (int) runCmd("awk -F: '\$3 >= 1000 && \$1 != \"nobody\" {print \$1}' /etc/passwd | wc -l");
    $xray_users = 0;
    if (file_exists(XRAY_CONFIG)) {
        $cfg = json_decode(file_get_contents(XRAY_CONFIG), true);
        foreach ($cfg['inbounds'] ?? [] as $inbound)
            $xray_users += count($inbound['settings']['clients'] ?? []);
    }
    $mem_total = (int) runCmd("grep MemTotal /proc/meminfo | awk '{print \$2}'");
    $mem_avail = (int) runCmd("grep MemAvailable /proc/meminfo | awk '{print \$2}'");
    $mem_used  = round(($mem_total - $mem_avail) / 1024);
    $mem_total_mb = round($mem_total / 1024);
    $ram_str = $mem_total > 0 ? $mem_used . '/' . $mem_total_mb . 'MB' : '0/0MB';

    $uptime_raw = (int) runCmd("awk '{print int(\$1)}' /proc/uptime");
    $days  = intdiv($uptime_raw, 86400);
    $hours = intdiv($uptime_raw % 86400, 3600);
    $uptime_str = $days > 0 ? "{$days}d {$hours}h" : "{$hours}h";

    ok([
        'ssh_users'  => $ssh_users,
        'xray_users' => $xray_users,
        'ram'        => $ram_str,
        'uptime'     => $uptime_str,
        'ip'         => getIP(),
    ]);

// ── CREATE SSH ───────────────────────────────────────────
case 'create_ssh':
    $user = trim($input['user'] ?? '');
    $pass = trim($input['pass'] ?? '');
    $exp  = (int)($input['exp'] ?? 30);
    $host = getDomain();

    if (!validateUser($user)) fail('Username tidak valid (3-20 karakter, huruf/angka/_-)');
    if (strlen($pass) < 4)    fail('Password minimal 4 karakter');
    if ($exp < 1 || $exp > 365) fail('Expired tidak valid (1-365 hari)');

    // Cek user sudah ada
    $check = runCmd("id {$user}");
    if (strpos($check, 'uid=') !== false) fail("User '{$user}' sudah ada!");

    $exp_date = date('Y-m-d', strtotime("+{$exp} days"));
    runCmd("useradd -e {$exp_date} -s /bin/false -M {$user}");
    runCmd("echo '{$user}:{$pass}' | chpasswd");

    $log = date('Y-m-d H:i:s') . " | user: {$user} | pass: {$pass} | exp: {$exp_date}\n";
    file_put_contents(SSH_LOG, $log, FILE_APPEND);

    ok([
        'user' => $user, 'pass' => $pass,
        'exp'  => $exp,  'exp_date' => $exp_date, 'host' => $host,
    ], 'SSH account created');

// ── CREATE VMESS ─────────────────────────────────────────
case 'create_vmess':
    $user = trim($input['user'] ?? '');
    $exp  = (int)($input['exp'] ?? 30);
    $host = getDomain();

    if (!validateUser($user)) fail('Username tidak valid');
    if ($exp < 1 || $exp > 365) fail('Expired tidak valid');

    $uuid = runCmd('cat /proc/sys/kernel/random/uuid');
    if (empty($uuid)) fail('Gagal generate UUID');
    $exp_date = date('Y-m-d', strtotime("+{$exp} days"));

    if (!file_exists(XRAY_CONFIG)) fail('Xray config tidak ditemukan');
    $cfg = json_decode(file_get_contents(XRAY_CONFIG), true);
    if (!$cfg) fail('Xray config tidak valid');

    $added = false;
    foreach ($cfg['inbounds'] as &$inbound) {
        if (($inbound['protocol'] ?? '') === 'vmess') {
            $inbound['settings']['clients'][] = ['id'=>$uuid,'alterId'=>0,'email'=>$user.'@vmess'];
            $added = true; break;
        }
    }
    if (!$added) fail('Vmess inbound tidak ditemukan di xray config');
    file_put_contents(XRAY_CONFIG, json_encode($cfg, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
    runCmd('systemctl restart xray');

    $vmess_obj = ['v'=>'2','ps'=>$user,'add'=>$host,'port'=>'443','id'=>$uuid,
        'aid'=>'0','net'=>'ws','type'=>'none','host'=>$host,'path'=>'/vmess','tls'=>'tls','sni'=>$host];
    $link_tls  = 'vmess://' . base64_encode(json_encode($vmess_obj));
    $vmess_http = array_merge($vmess_obj, ['port'=>'80','tls'=>'','path'=>'/vmess-nontls']);
    $link_http  = 'vmess://' . base64_encode(json_encode($vmess_http));

    file_put_contents(VMESS_LOG, date('Y-m-d H:i:s')." | user:{$user} | uuid:{$uuid} | exp:{$exp_date}\n", FILE_APPEND);
    ok(['user'=>$user,'uuid'=>$uuid,'host'=>$host,'exp'=>$exp,'exp_date'=>$exp_date,
        'link_tls'=>$link_tls,'link_http'=>$link_http], 'Vmess account created');

// ── CREATE VLESS ─────────────────────────────────────────
case 'create_vless':
    $user = trim($input['user'] ?? '');
    $exp  = (int)($input['exp'] ?? 30);
    $host = getDomain();

    if (!validateUser($user)) fail('Username tidak valid');
    if ($exp < 1 || $exp > 365) fail('Expired tidak valid');

    $uuid = runCmd('cat /proc/sys/kernel/random/uuid');
    if (empty($uuid)) fail('Gagal generate UUID');
    $exp_date = date('Y-m-d', strtotime("+{$exp} days"));

    if (!file_exists(XRAY_CONFIG)) fail('Xray config tidak ditemukan');
    $cfg = json_decode(file_get_contents(XRAY_CONFIG), true);
    if (!$cfg) fail('Xray config tidak valid');

    $added = false;
    foreach ($cfg['inbounds'] as &$inbound) {
        if (($inbound['protocol'] ?? '') === 'vless') {
            $inbound['settings']['clients'][] = ['id'=>$uuid,'email'=>$user.'@vless'];
            $added = true; break;
        }
    }
    if (!$added) fail('Vless inbound tidak ditemukan di xray config');
    file_put_contents(XRAY_CONFIG, json_encode($cfg, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
    runCmd('systemctl restart xray');

    $link_tls  = "vless://{$uuid}@{$host}:443?encryption=none&security=tls&sni={$host}&type=ws&host={$host}&path=%2Fvless#{$user}";
    $link_http = "vless://{$uuid}@{$host}:80?encryption=none&security=none&type=ws&host={$host}&path=%2Fvless#{$user}";

    file_put_contents(VLESS_LOG, date('Y-m-d H:i:s')." | user:{$user} | uuid:{$uuid} | exp:{$exp_date}\n", FILE_APPEND);
    ok(['user'=>$user,'uuid'=>$uuid,'host'=>$host,'exp'=>$exp,'exp_date'=>$exp_date,
        'link_tls'=>$link_tls,'link_http'=>$link_http], 'Vless account created');

// ── CREATE TROJAN ────────────────────────────────────────
case 'create_trojan':
    $user = trim($input['user'] ?? '');
    $exp  = (int)($input['exp'] ?? 30);
    $host = getDomain();

    if (!validateUser($user)) fail('Username tidak valid');
    if ($exp < 1 || $exp > 365) fail('Expired tidak valid');

    $pass     = generatePassword(12);
    $exp_date = date('Y-m-d', strtotime("+{$exp} days"));

    if (!file_exists(XRAY_CONFIG)) fail('Xray config tidak ditemukan');
    $cfg = json_decode(file_get_contents(XRAY_CONFIG), true);
    if (!$cfg) fail('Xray config tidak valid');

    $added = false;
    foreach ($cfg['inbounds'] as &$inbound) {
        if (($inbound['protocol'] ?? '') === 'trojan') {
            $inbound['settings']['clients'][] = ['password'=>$pass,'email'=>$user.'@trojan'];
            $added = true; break;
        }
    }
    if (!$added) fail('Trojan inbound tidak ditemukan di xray config');
    file_put_contents(XRAY_CONFIG, json_encode($cfg, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
    runCmd('systemctl restart xray');

    $link_tls  = "trojan://{$pass}@{$host}:443?security=tls&sni={$host}&type=ws&host={$host}&path=%2Ftrojan-ws#{$user}";
    $link_http = "trojan://{$pass}@{$host}:80?security=none&type=ws&host={$host}&path=%2Ftrojan-ws#{$user}";

    file_put_contents(TROJAN_LOG, date('Y-m-d H:i:s')." | user:{$user} | pass:{$pass} | exp:{$exp_date}\n", FILE_APPEND);
    ok(['user'=>$user,'pass'=>$pass,'host'=>$host,'exp'=>$exp,'exp_date'=>$exp_date,
        'link_tls'=>$link_tls,'link_http'=>$link_http], 'Trojan account created');

// ── CREATE SHADOWSOCKS ───────────────────────────────────
case 'create_ss':
    $user = trim($input['user'] ?? '');
    $exp  = (int)($input['exp'] ?? 30);
    $host = getDomain();

    if (!validateUser($user)) fail('Username tidak valid');
    if ($exp < 1 || $exp > 365) fail('Expired tidak valid');

    $pass     = generatePassword(12);
    $exp_date = date('Y-m-d', strtotime("+{$exp} days"));
    $method   = 'aes-128-gcm';

    if (!file_exists(XRAY_CONFIG)) fail('Xray config tidak ditemukan');
    $cfg = json_decode(file_get_contents(XRAY_CONFIG), true);
    if (!$cfg) fail('Xray config tidak valid');

    $added = false;
    foreach ($cfg['inbounds'] as &$inbound) {
        if (($inbound['protocol'] ?? '') === 'shadowsocks') {
            $inbound['settings']['clients'][] = ['method'=>$method,'password'=>$pass,'email'=>$user.'@ss'];
            $added = true; break;
        }
    }
    if (!$added) fail('Shadowsocks inbound tidak ditemukan di xray config');
    file_put_contents(XRAY_CONFIG, json_encode($cfg, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
    runCmd('systemctl restart xray');

    $ss_b64    = base64_encode("{$method}:{$pass}");
    $link_tls  = "ss://{$ss_b64}@{$host}:443?plugin=v2ray-plugin%3Btls%3Bmode%3Dwebsocket%3Bpath%3D%2Fss-ws%3Bhost%3D{$host}#{$user}";
    $link_http = "ss://{$ss_b64}@{$host}:80?plugin=v2ray-plugin%3Bmode%3Dwebsocket%3Bpath%3D%2Fss-ws%3Bhost%3D{$host}#{$user}";

    file_put_contents(SS_LOG, date('Y-m-d H:i:s')." | user:{$user} | pass:{$pass} | exp:{$exp_date}\n", FILE_APPEND);
    ok(['user'=>$user,'pass'=>$pass,'method'=>$method,'host'=>$host,'exp'=>$exp,'exp_date'=>$exp_date,
        'link_tls'=>$link_tls,'link_http'=>$link_http], 'Shadowsocks account created');

// ── LIST USERS ───────────────────────────────────────────
case 'list_users':
    $ssh_users = [];
    $lines = explode("\n", runCmd("awk -F: '\$3 >= 1000 && \$1 != \"nobody\" {print \$1}' /etc/passwd"));
    foreach ($lines as $line) {
        $u = trim($line);
        if (empty($u)) continue;
        $exp_raw = runCmd("chage -l {$u} | grep 'Account expires' | cut -d: -f2");
        $lock    = runCmd("passwd -S {$u} | awk '{print \$2}'");
        $status  = in_array($lock, ['L','LK']) ? 'locked' : 'active';
        $ssh_users[] = ['user'=>$u, 'exp'=>trim($exp_raw)?: 'never', 'status'=>$status];
    }

    $xray_users = [];
    if (file_exists(XRAY_CONFIG)) {
        $cfg = json_decode(file_get_contents(XRAY_CONFIG), true);
        foreach ($cfg['inbounds'] ?? [] as $inbound) {
            $proto = $inbound['protocol'] ?? '';
            foreach ($inbound['settings']['clients'] ?? [] as $c) {
                $email = $c['email'] ?? '';
                $uname = preg_replace('/@.*/', '', $email) ?: 'unknown';
                $xray_users[] = ['user'=>$uname, 'type'=>strtoupper($proto), 'exp'=>'see log'];
            }
        }
    }
    ok(['ssh'=>$ssh_users, 'xray'=>$xray_users]);

// ── DELETE SSH ───────────────────────────────────────────
case 'delete_ssh':
    $user = trim($input['user'] ?? '');
    if (!validateUser($user)) fail('Username tidak valid');
    $check = runCmd("id {$user}");
    if (strpos($check, 'uid=') === false) fail("User '{$user}' tidak ditemukan");
    runCmd("pkill -u {$user}");
    runCmd("userdel -f {$user}");
    ok([], "User SSH '{$user}' berhasil dihapus");

// ── DELETE XRAY ──────────────────────────────────────────
case 'delete_xray':
    $user = trim($input['user'] ?? '');
    $type = strtolower($input['type'] ?? '');
    if (!validateUser($user)) fail('Username tidak valid');
    if (!file_exists(XRAY_CONFIG)) fail('Xray config tidak ditemukan');

    $cfg = json_decode(file_get_contents(XRAY_CONFIG), true);
    $deleted = false;
    foreach ($cfg['inbounds'] as &$inbound) {
        if (strtolower($inbound['protocol'] ?? '') !== $type) continue;
        $before = count($inbound['settings']['clients'] ?? []);
        $inbound['settings']['clients'] = array_values(array_filter(
            $inbound['settings']['clients'] ?? [],
            fn($c) => !str_starts_with($c['email'] ?? '', $user . '@')
        ));
        if (count($inbound['settings']['clients']) < $before) $deleted = true;
    }
    if (!$deleted) fail("User '{$user}' tidak ditemukan di {$type}");
    file_put_contents(XRAY_CONFIG, json_encode($cfg, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
    runCmd('systemctl restart xray');
    ok([], "User {$type} '{$user}' berhasil dihapus");

// ── SERVICE STATUS ───────────────────────────────────────
case 'service_status':
    $services = ['xray','nginx','ssh','dropbear','stunnel4','ws-dropbear','ws-stunnel','fail2ban','vnstat','cron'];
    $names    = ['Xray','Nginx','SSH','Dropbear','Stunnel4','WS-Dropbear','WS-Stunnel','Fail2Ban','Vnstat','Cron'];
    $result   = [];
    foreach ($services as $i => $svc) {
        $status = runCmd("systemctl is-active {$svc}");
        $result[] = ['name'=>$names[$i], 'svc'=>$svc, 'status'=>$status];
    }
    ok($result);

// ── RESTART SERVICE ──────────────────────────────────────
case 'restart_service':
    $name    = $input['name'] ?? '';
    $allowed = ['xray','nginx','ssh','dropbear','stunnel4','ws-dropbear','ws-stunnel','fail2ban','vnstat','cron'];
    if (!in_array($name, $allowed)) fail('Service tidak diizinkan');
    runCmd("systemctl restart {$name}");
    $status = runCmd("systemctl is-active {$name}");
    if ($status === 'active') ok([], "{$name} berhasil direstart");
    else fail("{$name} gagal restart, status: {$status}");

default:
    fail('Action tidak dikenal: ' . $action);
}
