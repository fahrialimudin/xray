<?php
// Deteksi domain/IP
$domain = '';
if (file_exists('/etc/xray/domain')) $domain = trim(file_get_contents('/etc/xray/domain'));
if (empty($domain) && file_exists('/etc/myipvps')) $domain = trim(file_get_contents('/etc/myipvps'));
if (empty($domain)) $domain = $_SERVER['HTTP_HOST'] ?? 'your-domain.com';
$domain = explode(':', $domain)[0]; // hapus port jika ada
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>VPN Panel</title>
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600;700&family=DM+Mono:wght@400;500&display=swap" rel="stylesheet">
<style>
  :root {
    --blue: #1d6fe8;
    --blue-light: #e8f0fd;
    --blue-mid: #3b82f6;
    --navy: #1e3a5f;
    --white: #ffffff;
    --gray-50: #f8fafc;
    --gray-100: #f1f5f9;
    --gray-200: #e2e8f0;
    --gray-400: #94a3b8;
    --gray-600: #475569;
    --gray-800: #1e293b;
    --green: #10b981;
    --red: #ef4444;
    --orange: #f59e0b;
    --shadow-sm: 0 1px 3px rgba(0,0,0,0.06);
    --shadow: 0 4px 16px rgba(29,111,232,0.08);
    --shadow-lg: 0 8px 32px rgba(29,111,232,0.14);
    --radius: 14px;
    --radius-sm: 8px;
  }
  * { margin:0; padding:0; box-sizing:border-box; }
  body {
    font-family: 'DM Sans', sans-serif;
    background: var(--gray-50);
    color: var(--gray-800);
    min-height: 100vh;
  }

  /* SIDEBAR */
  .sidebar {
    position: fixed; left:0; top:0; bottom:0;
    width: 230px;
    background: var(--white);
    border-right: 1px solid var(--gray-200);
    display: flex; flex-direction: column;
    z-index: 100;
    box-shadow: 2px 0 12px rgba(0,0,0,0.04);
  }
  .sidebar-logo {
    padding: 24px 20px 20px;
    border-bottom: 1px solid var(--gray-100);
    display: flex; align-items: center; gap: 10px;
  }
  .logo-icon {
    width: 36px; height: 36px;
    background: linear-gradient(135deg, var(--blue), var(--blue-mid));
    border-radius: 10px;
    display: flex; align-items: center; justify-content: center;
    font-size: 18px;
  }
  .logo-text { font-size: 17px; font-weight: 700; color: var(--navy); }
  .logo-sub { font-size: 11px; color: var(--gray-400); font-weight: 400; }

  .sidebar-nav { flex:1; padding: 16px 12px; overflow-y:auto; }
  .nav-label {
    font-size: 10px; font-weight: 600; letter-spacing: 0.08em;
    color: var(--gray-400); text-transform: uppercase;
    padding: 0 8px; margin: 12px 0 6px;
  }
  .nav-item {
    display: flex; align-items: center; gap: 10px;
    padding: 9px 12px; border-radius: var(--radius-sm);
    cursor: pointer; font-size: 14px; font-weight: 500;
    color: var(--gray-600); transition: all 0.15s;
    margin-bottom: 2px;
  }
  .nav-item:hover { background: var(--blue-light); color: var(--blue); }
  .nav-item.active { background: var(--blue-light); color: var(--blue); font-weight: 600; }
  .nav-item .icon { font-size: 16px; width: 20px; text-align:center; }

  .sidebar-footer {
    padding: 16px;
    border-top: 1px solid var(--gray-100);
    font-size: 12px; color: var(--gray-400);
    text-align: center;
  }
  .server-badge {
    display: inline-flex; align-items: center; gap: 5px;
    background: var(--gray-100); border-radius: 20px;
    padding: 4px 10px; font-size: 11px; color: var(--gray-600);
  }
  .dot { width:6px;height:6px;border-radius:50%;background:var(--green);display:inline-block; }

  /* MAIN */
  .main { margin-left: 230px; min-height:100vh; }
  .topbar {
    background: var(--white); border-bottom: 1px solid var(--gray-200);
    padding: 16px 28px; display:flex; align-items:center; justify-content:space-between;
    position:sticky; top:0; z-index:50;
  }
  .topbar-title { font-size: 18px; font-weight: 700; color: var(--navy); }
  .topbar-ip {
    font-family: 'DM Mono', monospace;
    font-size: 13px; color: var(--gray-600);
    background: var(--gray-100); padding: 5px 12px; border-radius: 20px;
  }

  .content { padding: 24px 28px; }

  /* STATS GRID */
  .stats-grid {
    display: grid; grid-template-columns: repeat(4,1fr); gap: 16px;
    margin-bottom: 24px;
  }
  .stat-card {
    background: var(--white); border-radius: var(--radius);
    padding: 20px; border: 1px solid var(--gray-200);
    box-shadow: var(--shadow-sm);
    transition: box-shadow 0.2s;
  }
  .stat-card:hover { box-shadow: var(--shadow); }
  .stat-label { font-size: 12px; color: var(--gray-400); font-weight: 500; margin-bottom: 6px; }
  .stat-value { font-size: 26px; font-weight: 700; color: var(--navy); }
  .stat-icon { font-size: 22px; margin-bottom: 8px; }

  /* PANEL SECTION */
  .panel-card {
    background: var(--white); border-radius: var(--radius);
    border: 1px solid var(--gray-200); box-shadow: var(--shadow-sm);
    overflow: hidden; margin-bottom: 20px;
  }
  .panel-header {
    padding: 18px 22px; border-bottom: 1px solid var(--gray-100);
    display: flex; align-items: center; gap: 10px;
  }
  .panel-header h2 { font-size: 15px; font-weight: 700; color: var(--navy); }
  .panel-body { padding: 22px; }

  /* TABS */
  .tabs {
    display: flex; gap: 6px; flex-wrap: wrap;
    background: var(--gray-100); padding: 5px; border-radius: 10px;
    margin-bottom: 22px;
  }
  .tab-btn {
    padding: 7px 16px; border-radius: 7px; border: none;
    cursor: pointer; font-size: 13px; font-weight: 500;
    color: var(--gray-600); background: transparent;
    transition: all 0.15s; font-family: 'DM Sans', sans-serif;
  }
  .tab-btn.active {
    background: var(--white); color: var(--blue);
    font-weight: 600; box-shadow: 0 1px 4px rgba(0,0,0,0.08);
  }
  .tab-btn:hover:not(.active) { color: var(--blue); }

  /* FORMS */
  .form-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; margin-bottom: 16px; }
  .form-group { display: flex; flex-direction: column; gap: 5px; }
  .form-group.full { grid-column: 1/-1; }
  label { font-size: 12px; font-weight: 600; color: var(--gray-600); }
  input[type=text], input[type=password], input[type=number] {
    padding: 9px 12px; border: 1.5px solid var(--gray-200);
    border-radius: var(--radius-sm); font-size: 14px;
    font-family: 'DM Sans', sans-serif; color: var(--gray-800);
    background: var(--gray-50); transition: all 0.15s; outline: none;
  }
  input:focus { border-color: var(--blue); background: var(--white); box-shadow: 0 0 0 3px rgba(29,111,232,0.08); }

  .btn {
    padding: 10px 22px; border: none; border-radius: var(--radius-sm);
    font-size: 14px; font-weight: 600; cursor: pointer;
    font-family: 'DM Sans', sans-serif; transition: all 0.15s;
    display: inline-flex; align-items: center; gap: 6px;
  }
  .btn-primary { background: var(--blue); color: white; }
  .btn-primary:hover { background: #1558c0; box-shadow: 0 4px 12px rgba(29,111,232,0.3); }
  .btn-danger { background: #fef2f2; color: var(--red); border: 1.5px solid #fecaca; }
  .btn-danger:hover { background: #fee2e2; }
  .btn-sm { padding: 6px 12px; font-size: 12px; }

  /* RESULT BOX */
  .result-box {
    display:none; margin-top: 16px;
    background: var(--gray-50); border: 1.5px solid var(--gray-200);
    border-radius: var(--radius-sm); padding: 16px;
  }
  .result-box.show { display: block; }
  .result-box.success { background: #f0fdf4; border-color: #86efac; }
  .result-box.error { background: #fef2f2; border-color: #fca5a5; }
  .result-title { font-size: 13px; font-weight: 700; margin-bottom: 10px; }
  .result-title.ok { color: var(--green); }
  .result-title.err { color: var(--red); }
  .result-row { display:flex; gap:8px; margin-bottom:6px; font-size:13px; }
  .result-key { color: var(--gray-400); min-width: 90px; font-weight:500; }
  .result-val { font-family: 'DM Mono', monospace; color: var(--gray-800); word-break:break-all; }
  .copy-link {
    display:block; margin-top:8px; padding:8px 10px;
    background: var(--white); border:1.5px solid var(--gray-200);
    border-radius: var(--radius-sm); font-family:'DM Mono',monospace;
    font-size:11px; color: var(--blue); word-break:break-all;
    cursor:pointer; transition: all 0.15s;
  }
  .copy-link:hover { border-color:var(--blue); background: var(--blue-light); }

  /* TABLE */
  .table-wrap { overflow-x:auto; }
  table { width:100%; border-collapse:collapse; font-size:13px; }
  th {
    padding: 10px 14px; text-align:left;
    background: var(--gray-50); font-size:11px; font-weight:600;
    color: var(--gray-400); text-transform:uppercase; letter-spacing:0.05em;
    border-bottom: 1px solid var(--gray-200);
  }
  td { padding: 12px 14px; border-bottom: 1px solid var(--gray-100); }
  tr:last-child td { border-bottom: none; }
  tr:hover td { background: var(--gray-50); }
  .badge {
    display:inline-flex; align-items:center; gap:4px;
    padding: 2px 8px; border-radius: 20px; font-size:11px; font-weight:600;
  }
  .badge-green { background:#dcfce7; color:#166534; }
  .badge-red { background:#fee2e2; color:#991b1b; }
  .badge-blue { background:var(--blue-light); color:var(--blue); }

  /* SERVICES */
  .svc-grid { display:grid; grid-template-columns:repeat(2,1fr); gap:10px; }
  .svc-item {
    display:flex; align-items:center; justify-content:space-between;
    padding:12px 14px; border:1px solid var(--gray-200);
    border-radius:var(--radius-sm); background:var(--gray-50);
  }
  .svc-name { font-size:13px; font-weight:600; }
  .svc-port { font-size:11px; color:var(--gray-400); font-family:'DM Mono',monospace; }
  .svc-actions { display:flex; gap:6px; align-items:center; }

  /* LOADING */
  .spinner {
    width:16px;height:16px;border:2px solid rgba(255,255,255,0.3);
    border-top-color:white;border-radius:50%;
    animation:spin 0.6s linear infinite;display:none;
  }
  @keyframes spin { to { transform:rotate(360deg); } }
  .btn.loading .spinner { display:inline-block; }
  .btn.loading .btn-text { opacity:0.7; }

  /* PAGE SECTIONS */
  .page { display:none; }
  .page.active { display:block; }

  /* MOBILE */
  .hamburger { display:none; }
  @media(max-width:768px){
    .sidebar { transform:translateX(-100%); transition:transform 0.25s; }
    .sidebar.open { transform:translateX(0); }
    .main { margin-left:0; }
    .stats-grid { grid-template-columns:1fr 1fr; }
    .form-grid { grid-template-columns:1fr; }
    .svc-grid { grid-template-columns:1fr; }
    .hamburger {
      display:block; position:fixed; top:14px; left:14px; z-index:200;
      background:var(--blue); color:white; border:none; border-radius:8px;
      width:36px;height:36px;font-size:18px;cursor:pointer;
    }
    .topbar { padding-left:60px; }
    .overlay {
      display:none; position:fixed; inset:0;
      background:rgba(0,0,0,0.3); z-index:99;
    }
    .overlay.show { display:block; }
  }

  .toast {
    position:fixed; bottom:20px; right:20px;
    background:var(--navy); color:white; padding:10px 18px;
    border-radius:var(--radius-sm); font-size:13px; font-weight:500;
    box-shadow:var(--shadow-lg); opacity:0; pointer-events:none;
    transition:opacity 0.2s; z-index:999;
  }
  .toast.show { opacity:1; }
</style>
</head>
<body>

<button class="hamburger" onclick="toggleSidebar()">☰</button>
<div class="overlay" id="overlay" onclick="toggleSidebar()"></div>

<!-- SIDEBAR -->
<aside class="sidebar" id="sidebar">
  <div class="sidebar-logo">
    <div class="logo-icon">🛡️</div>
    <div>
      <div class="logo-text">VPNPanel</div>
      <div class="logo-sub">Server Manager</div>
    </div>
  </div>

  <nav class="sidebar-nav">
    <div class="nav-label">Overview</div>
    <div class="nav-item active" onclick="showPage('dashboard',this)">
      <span class="icon">📊</span> Dashboard
    </div>

    <div class="nav-label">Create Account</div>
    <div class="nav-item" onclick="showPage('ssh',this)">
      <span class="icon">🔑</span> SSH Account
    </div>
    <div class="nav-item" onclick="showPage('vmess',this)">
      <span class="icon">⚡</span> Vmess
    </div>
    <div class="nav-item" onclick="showPage('vless',this)">
      <span class="icon">🚀</span> Vless
    </div>
    <div class="nav-item" onclick="showPage('trojan',this)">
      <span class="icon">🐴</span> Trojan
    </div>
    <div class="nav-item" onclick="showPage('shadowsocks',this)">
      <span class="icon">👥</span> Shadowsocks
    </div>

    <div class="nav-label">Management</div>
    <div class="nav-item" onclick="showPage('users',this)">
      <span class="icon">👤</span> User List
    </div>
    <div class="nav-item" onclick="showPage('services',this)">
      <span class="icon">⚙️</span> Services
    </div>
  </nav>

  <div class="sidebar-footer">
    <div class="server-badge">
      <span class="dot"></span>
      <span id="sb-ip">Loading...</span>
    </div>
  </div>
</aside>

<!-- MAIN -->
<main class="main">
  <div class="topbar">
    <div class="topbar-title" id="page-title">Dashboard</div>
    <div class="topbar-ip" id="top-ip">⏳ Loading...</div>
  </div>

  <div class="content">

    <!-- DASHBOARD -->
    <div class="page active" id="page-dashboard">
      <div class="stats-grid">
        <div class="stat-card">
          <div class="stat-icon">👤</div>
          <div class="stat-label">SSH Users</div>
          <div class="stat-value" id="stat-ssh">—</div>
        </div>
        <div class="stat-card">
          <div class="stat-icon">⚡</div>
          <div class="stat-label">Xray Users</div>
          <div class="stat-value" id="stat-xray">—</div>
        </div>
        <div class="stat-card">
          <div class="stat-icon">💾</div>
          <div class="stat-label">RAM Usage</div>
          <div class="stat-value" id="stat-ram">—</div>
        </div>
        <div class="stat-card">
          <div class="stat-icon">⏱️</div>
          <div class="stat-label">Uptime</div>
          <div class="stat-value" id="stat-uptime">—</div>
        </div>
      </div>

      <div class="panel-card">
        <div class="panel-header">
          <span>🌐</span>
          <h2>Server Information</h2>
        </div>
        <div class="panel-body">
          <div class="form-grid">
            <div class="form-group">
              <label>IP Address</label>
              <input type="text" id="info-ip" readonly>
            </div>
            <div class="form-group">
              <label>Domain</label>
              <input type="text" id="info-domain" value="<?= htmlspecialchars($domain) ?>" readonly>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- SSH PAGE -->
    <div class="page" id="page-ssh">
      <div class="panel-card">
        <div class="panel-header"><span>🔑</span><h2>Create SSH Account</h2></div>
        <div class="panel-body">
          <div class="form-grid">
            <div class="form-group">
              <label>Username</label>
              <input type="text" id="ssh-user" placeholder="contoh: john123">
            </div>
            <div class="form-group">
              <label>Password</label>
              <input type="password" id="ssh-pass" placeholder="Min. 4 karakter">
            </div>
            <div class="form-group">
              <label>Expired (Hari)</label>
              <input type="number" id="ssh-exp" value="30" min="1" max="365">
            </div>
          </div>
          <button class="btn btn-primary" onclick="createSSH(this)">
            <span class="btn-text">🔑 Buat SSH Account</span>
            <span class="spinner"></span>
          </button>
          <div class="result-box" id="ssh-result"></div>
        </div>
      </div>
    </div>

    <!-- VMESS PAGE -->
    <div class="page" id="page-vmess">
      <div class="panel-card">
        <div class="panel-header"><span>⚡</span><h2>Create Vmess Account</h2></div>
        <div class="panel-body">
          <div class="form-grid">
            <div class="form-group">
              <label>Username</label>
              <input type="text" id="vmess-user" placeholder="contoh: john123">
            </div>
            <div class="form-group">
              <label>Expired (Hari)</label>
              <input type="number" id="vmess-exp" value="30" min="1" max="365">
            </div>
          </div>
          <button class="btn btn-primary" onclick="createVmess(this)">
            <span class="btn-text">⚡ Buat Vmess Account</span>
            <span class="spinner"></span>
          </button>
          <div class="result-box" id="vmess-result"></div>
        </div>
      </div>
    </div>

    <!-- VLESS PAGE -->
    <div class="page" id="page-vless">
      <div class="panel-card">
        <div class="panel-header"><span>🚀</span><h2>Create Vless Account</h2></div>
        <div class="panel-body">
          <div class="form-grid">
            <div class="form-group">
              <label>Username</label>
              <input type="text" id="vless-user" placeholder="contoh: john123">
            </div>
            <div class="form-group">
              <label>Expired (Hari)</label>
              <input type="number" id="vless-exp" value="30" min="1" max="365">
            </div>
          </div>
          <button class="btn btn-primary" onclick="createVless(this)">
            <span class="btn-text">🚀 Buat Vless Account</span>
            <span class="spinner"></span>
          </button>
          <div class="result-box" id="vless-result"></div>
        </div>
      </div>
    </div>

    <!-- TROJAN PAGE -->
    <div class="page" id="page-trojan">
      <div class="panel-card">
        <div class="panel-header"><span>🐴</span><h2>Create Trojan Account</h2></div>
        <div class="panel-body">
          <div class="form-grid">
            <div class="form-group">
              <label>Username</label>
              <input type="text" id="trojan-user" placeholder="contoh: john123">
            </div>
            <div class="form-group">
              <label>Expired (Hari)</label>
              <input type="number" id="trojan-exp" value="30" min="1" max="365">
            </div>
          </div>
          <button class="btn btn-primary" onclick="createTrojan(this)">
            <span class="btn-text">🐴 Buat Trojan Account</span>
            <span class="spinner"></span>
          </button>
          <div class="result-box" id="trojan-result"></div>
        </div>
      </div>
    </div>

    <!-- SHADOWSOCKS PAGE -->
    <div class="page" id="page-shadowsocks">
      <div class="panel-card">
        <div class="panel-header"><span>👥</span><h2>Create Shadowsocks Account</h2></div>
        <div class="panel-body">
          <div class="form-grid">
            <div class="form-group">
              <label>Username</label>
              <input type="text" id="ss-user" placeholder="contoh: john123">
            </div>
            <div class="form-group">
              <label>Expired (Hari)</label>
              <input type="number" id="ss-exp" value="30" min="1" max="365">
            </div>
          </div>
          <button class="btn btn-primary" onclick="createSS(this)">
            <span class="btn-text">👥 Buat Shadowsocks Account</span>
            <span class="spinner"></span>
          </button>
          <div class="result-box" id="ss-result"></div>
        </div>
      </div>
    </div>

    <!-- USERS PAGE -->
    <div class="page" id="page-users">
      <div class="panel-card">
        <div class="panel-header">
          <span>👤</span><h2>Daftar User</h2>
          <button class="btn btn-primary btn-sm" style="margin-left:auto" onclick="loadUsers()">🔄 Refresh</button>
        </div>
        <div class="panel-body">
          <div class="tabs">
            <button class="tab-btn active" onclick="switchUserTab('ssh',this)">SSH</button>
            <button class="tab-btn" onclick="switchUserTab('xray',this)">Xray (Vmess/Vless/Trojan/SS)</button>
          </div>
          <div class="table-wrap" id="users-ssh">
            <table><thead><tr><th>Username</th><th>Expired</th><th>Status</th><th>Aksi</th></tr></thead>
            <tbody id="tb-ssh"><tr><td colspan="4" style="text-align:center;color:var(--gray-400)">Memuat...</td></tr></tbody></table>
          </div>
          <div class="table-wrap" id="users-xray" style="display:none">
            <table><thead><tr><th>Username</th><th>Tipe</th><th>Info</th><th>Aksi</th></tr></thead>
            <tbody id="tb-xray"><tr><td colspan="4" style="text-align:center;color:var(--gray-400)">Memuat...</td></tr></tbody></table>
          </div>
        </div>
      </div>
    </div>

    <!-- SERVICES PAGE -->
    <div class="page" id="page-services">
      <div class="panel-card">
        <div class="panel-header">
          <span>⚙️</span><h2>Status Services</h2>
          <button class="btn btn-primary btn-sm" style="margin-left:auto" onclick="loadServices()">🔄 Refresh</button>
        </div>
        <div class="panel-body">
          <div class="svc-grid" id="svc-grid">
            <div style="color:var(--gray-400);text-align:center;padding:20px;grid-column:1/-1">Memuat...</div>
          </div>
        </div>
      </div>
    </div>

  </div>
</main>

<div class="toast" id="toast"></div>

<script>
const API = 'api.php';

// ── Helpers ────────────────────────────────────────────────
async function callApi(data) {
  const r = await fetch(API, {
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify(data)
  });
  return r.json();
}

function toast(msg, dur=2500) {
  const t = document.getElementById('toast');
  t.textContent = msg; t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), dur);
}

function copyText(text) {
  navigator.clipboard.writeText(text).then(() => toast('✅ Disalin!'));
}

function setLoading(btn, on) {
  btn.classList.toggle('loading', on);
  btn.disabled = on;
}

function showResult(id, res, fields, links=[]) {
  const box = document.getElementById(id);
  if (!res.success) {
    box.className = 'result-box show error';
    box.innerHTML = `<div class="result-title err">❌ Gagal</div><div style="font-size:13px;color:var(--red)">${res.message}</div>`;
    return;
  }
  let html = `<div class="result-title ok">✅ Berhasil Dibuat!</div>`;
  fields.forEach(([k,v]) => {
    html += `<div class="result-row"><span class="result-key">${k}</span><span class="result-val">${v}</span></div>`;
  });
  links.forEach(([label, url]) => {
    html += `<div style="margin-top:6px;font-size:12px;font-weight:600;color:var(--gray-600)">${label}:</div>`;
    html += `<div class="copy-link" onclick="copyText('${url.replace(/'/g,"\\'")}')" title="Klik untuk salin">${url}</div>`;
  });
  box.className = 'result-box show success';
  box.innerHTML = html;
}

// ── Navigation ─────────────────────────────────────────────
function showPage(id, el) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  document.getElementById('page-'+id).classList.add('active');
  el.classList.add('active');
  const titles = {dashboard:'Dashboard',ssh:'Buat SSH',vmess:'Buat Vmess',
    vless:'Buat Vless',trojan:'Buat Trojan',shadowsocks:'Buat Shadowsocks',
    users:'Daftar User',services:'Status Services'};
  document.getElementById('page-title').textContent = titles[id] || id;
  if (id==='users') loadUsers();
  if (id==='services') loadServices();
  if (window.innerWidth <= 768) toggleSidebar();
}

function toggleSidebar() {
  document.getElementById('sidebar').classList.toggle('open');
  document.getElementById('overlay').classList.toggle('show');
}

function switchUserTab(tab, btn) {
  document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  document.getElementById('users-ssh').style.display = tab==='ssh' ? '' : 'none';
  document.getElementById('users-xray').style.display = tab==='xray' ? '' : 'none';
}

// ── Stats ──────────────────────────────────────────────────
async function loadStats() {
  try {
    const res = await callApi({action:'stats'});
    if (res.success) {
      document.getElementById('stat-ssh').textContent = res.data.ssh_users;
      document.getElementById('stat-xray').textContent = res.data.xray_users;
      document.getElementById('stat-ram').textContent = res.data.ram;
      document.getElementById('stat-uptime').textContent = res.data.uptime;
      document.getElementById('info-ip').value = res.data.ip;
      document.getElementById('top-ip').textContent = '🌐 ' + res.data.ip;
      document.getElementById('sb-ip').textContent = res.data.ip;
    }
  } catch(e) { console.error(e); }
}

// ── Create SSH ─────────────────────────────────────────────
async function createSSH(btn) {
  const user = document.getElementById('ssh-user').value.trim();
  const pass = document.getElementById('ssh-pass').value.trim();
  const exp  = document.getElementById('ssh-exp').value;
  if (!user||!pass) return toast('❗ Username dan password wajib diisi');
  setLoading(btn, true);
  const res = await callApi({action:'create_ssh', user, pass, exp:parseInt(exp)});
  setLoading(btn, false);
  const d = res.data || {};
  showResult('ssh-result', res, [
    ['Username', d.user||''], ['Password', d.pass||''],
    ['Expired', d.exp_date||''], ['Host', d.host||'']
  ]);
  if (res.success) loadStats();
}

// ── Create Vmess ───────────────────────────────────────────
async function createVmess(btn) {
  const user = document.getElementById('vmess-user').value.trim();
  const exp  = document.getElementById('vmess-exp').value;
  if (!user) return toast('❗ Username wajib diisi');
  setLoading(btn, true);
  const res = await callApi({action:'create_vmess', user, exp:parseInt(exp)});
  setLoading(btn, false);
  const d = res.data || {};
  showResult('vmess-result', res, [
    ['Username', d.user||''], ['UUID', d.uuid||''],
    ['Host', d.host||''], ['Expired', d.exp_date||'']
  ], [
    ['Link TLS (443)', d.link_tls||''],
    ['Link HTTP (80)', d.link_http||'']
  ]);
  if (res.success) loadStats();
}

// ── Create Vless ───────────────────────────────────────────
async function createVless(btn) {
  const user = document.getElementById('vless-user').value.trim();
  const exp  = document.getElementById('vless-exp').value;
  if (!user) return toast('❗ Username wajib diisi');
  setLoading(btn, true);
  const res = await callApi({action:'create_vless', user, exp:parseInt(exp)});
  setLoading(btn, false);
  const d = res.data || {};
  showResult('vless-result', res, [
    ['Username', d.user||''], ['UUID', d.uuid||''],
    ['Host', d.host||''], ['Expired', d.exp_date||'']
  ], [
    ['Link TLS (443)', d.link_tls||''],
    ['Link HTTP (80)', d.link_http||'']
  ]);
  if (res.success) loadStats();
}

// ── Create Trojan ──────────────────────────────────────────
async function createTrojan(btn) {
  const user = document.getElementById('trojan-user').value.trim();
  const exp  = document.getElementById('trojan-exp').value;
  if (!user) return toast('❗ Username wajib diisi');
  setLoading(btn, true);
  const res = await callApi({action:'create_trojan', user, exp:parseInt(exp)});
  setLoading(btn, false);
  const d = res.data || {};
  showResult('trojan-result', res, [
    ['Username', d.user||''], ['Password', d.pass||''],
    ['Host', d.host||''], ['Expired', d.exp_date||'']
  ], [
    ['Link TLS (443)', d.link_tls||''],
    ['Link HTTP (80)', d.link_http||'']
  ]);
  if (res.success) loadStats();
}

// ── Create Shadowsocks ─────────────────────────────────────
async function createSS(btn) {
  const user = document.getElementById('ss-user').value.trim();
  const exp  = document.getElementById('ss-exp').value;
  if (!user) return toast('❗ Username wajib diisi');
  setLoading(btn, true);
  const res = await callApi({action:'create_ss', user, exp:parseInt(exp)});
  setLoading(btn, false);
  const d = res.data || {};
  showResult('ss-result', res, [
    ['Username', d.user||''], ['Password', d.pass||''],
    ['Method', d.method||''], ['Host', d.host||''], ['Expired', d.exp_date||'']
  ], [
    ['Link TLS (443)', d.link_tls||''],
    ['Link HTTP (80)', d.link_http||'']
  ]);
  if (res.success) loadStats();
}

// ── Load Users ─────────────────────────────────────────────
async function loadUsers() {
  document.getElementById('tb-ssh').innerHTML = '<tr><td colspan="4" style="text-align:center;color:var(--gray-400)">Memuat...</td></tr>';
  document.getElementById('tb-xray').innerHTML = '<tr><td colspan="4" style="text-align:center;color:var(--gray-400)">Memuat...</td></tr>';
  const res = await callApi({action:'list_users'});
  if (!res.success) return;

  // SSH table
  const ssh = res.data.ssh || [];
  if (ssh.length === 0) {
    document.getElementById('tb-ssh').innerHTML = '<tr><td colspan="4" style="text-align:center;color:var(--gray-400)">Tidak ada user SSH</td></tr>';
  } else {
    document.getElementById('tb-ssh').innerHTML = ssh.map(u => `
      <tr>
        <td><strong>${u.user}</strong></td>
        <td style="font-family:'DM Mono',monospace;font-size:12px">${u.exp}</td>
        <td><span class="badge ${u.status==='active'?'badge-green':'badge-red'}">${u.status}</span></td>
        <td><button class="btn btn-danger btn-sm" onclick="deleteUser('ssh','${u.user}',this)">🗑️ Hapus</button></td>
      </tr>`).join('');
  }

  // Xray table
  const xray = res.data.xray || [];
  if (xray.length === 0) {
    document.getElementById('tb-xray').innerHTML = '<tr><td colspan="4" style="text-align:center;color:var(--gray-400)">Tidak ada user Xray</td></tr>';
  } else {
    document.getElementById('tb-xray').innerHTML = xray.map(u => `
      <tr>
        <td><strong>${u.user}</strong></td>
        <td><span class="badge badge-blue">${u.type}</span></td>
        <td style="font-size:12px;color:var(--gray-400)">Lihat log</td>
        <td><button class="btn btn-danger btn-sm" onclick="deleteUser('xray','${u.user}','${u.type.toLowerCase()}',this)">🗑️ Hapus</button></td>
      </tr>`).join('');
  }
}

async function deleteUser(mode, user, typeOrBtn, btn2) {
  let type='', btn;
  if (mode==='ssh') { btn=typeOrBtn; }
  else { type=typeOrBtn; btn=btn2; }
  if (!confirm(`Hapus user "${user}"?`)) return;
  setLoading(btn, true);
  let payload = mode==='ssh'
    ? {action:'delete_ssh', user}
    : {action:'delete_xray', user, type};
  const res = await callApi(payload);
  setLoading(btn, false);
  toast(res.success ? '✅ '+res.message : '❌ '+res.message);
  if (res.success) { loadUsers(); loadStats(); }
}

// ── Load Services ──────────────────────────────────────────
async function loadServices() {
  document.getElementById('svc-grid').innerHTML = '<div style="color:var(--gray-400);text-align:center;padding:20px;grid-column:1/-1">Memuat...</div>';
  const res = await callApi({action:'service_status'});
  if (!res.success) return;
  const ports = {
    'Xray':'443 / 80','Nginx':'80 / 443 / 8080','SSH':'22 / 9696',
    'Dropbear':'109 / 143','Stunnel4':'222 / 777',
    'WS-Dropbear':'2095','WS-Stunnel':'700',
    'Fail2Ban':'—','Vnstat':'—','Cron':'—'
  };
  document.getElementById('svc-grid').innerHTML = res.data.map(s => `
    <div class="svc-item">
      <div>
        <div class="svc-name">${s.name}</div>
        <div class="svc-port">Port: ${ports[s.name]||s.port||'—'}</div>
      </div>
      <div class="svc-actions">
        <span class="badge ${s.status==='active'?'badge-green':'badge-red'}">${s.status==='active'?'🟢 Aktif':'🔴 Mati'}</span>
        <button class="btn btn-primary btn-sm" onclick="restartSvc('${s.name.toLowerCase()}',this)">↺</button>
      </div>
    </div>`).join('');
}

async function restartSvc(name, btn) {
  setLoading(btn, true);
  const res = await callApi({action:'restart_service', name});
  setLoading(btn, false);
  toast(res.success ? '✅ '+res.message : '❌ '+res.message);
  if (res.success) setTimeout(loadServices, 1000);
}

// ── Init ───────────────────────────────────────────────────
loadStats();
setInterval(loadStats, 30000);
</script>
</body>
</html>
